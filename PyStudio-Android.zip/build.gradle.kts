// Top-level build file for PyStudio.
plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    id("com.chaquo.python") version "17.2.0" apply false
}
