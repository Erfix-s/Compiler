# Chaquopy: the Python interpreter and its native libraries must be kept.
-keep class com.chaquo.python.** { *; }
-keep class com.chaquo.python.android.** { *; }

# PyBridge is called from Python via the Chaquopy Java bridge.
-keep class com.pystudio.app.PyBridge { *; }
-keep class com.pystudio.app.PyBridge$* { *; }

-dontwarn com.chaquo.python.**
