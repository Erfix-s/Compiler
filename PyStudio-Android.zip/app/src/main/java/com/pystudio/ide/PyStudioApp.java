package com.pystudio.ide;

import android.app.Application;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/**
 * Starts CPython once per process and prepares the private workspace.
 */
public class PyStudioApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
        } catch (Throwable ignored) {
            // The interpreter is started lazily again when the user presses Run,
            // where a useful error can be shown in the Output tab.
        }
        Workspace.ensureSeeded(this);
    }
}
