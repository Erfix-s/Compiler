package com.pystudio.ide;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.TypedValue;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "pystudio_prefs";
    private static final String KEY_LAST_FILE = "last_file";
    private static final String KEY_EDITOR_FONT_SIZE = "editor_font_size";
    private static final String KEY_CONSOLE_FONT_SIZE = "console_font_size";
    private static final String KEY_INDENT_WIDTH = "indent_width";
    private static final String KEY_SHOW_LINE_NUMBERS = "show_line_numbers";
    private static final String KEY_AUTO_INDENT = "auto_indent";
    private static final String KEY_SYNTAX_HIGHLIGHTING = "syntax_highlighting";
    private static final String KEY_WORD_WRAP = "word_wrap";
    private static final String KEY_EDITOR_FONT_FAMILY = "editor_font_family";

    private enum PickerMode {NONE, INSERT_PATH, IMPORT_FILE}

    private PythonCodeView codeEditor;
    private TextView gutter;
    private TextView positionLabel;
    private TextView fileNameLabel;
    private TextView fileMetaLabel;
    private TextView editorTabLabel;
    private View dirtyDot;
    private MaterialButton runButton;
    private View runProgress;
    private LinearLayout bottomNav;
    private View tabEditor, tabOutput, tabTerminal, tabFiles;
    private ImageView tabIconEditor, tabIconOutput, tabIconTerminal, tabIconFiles;
    private TextView tabLabelEditor, tabLabelOutput, tabLabelTerminal, tabLabelFiles;
    private View topBar, editorActionsRow, editorStatusRow;
    private TextView headerSubtitle;
    private int selectedPageId = R.id.nav_editor;
    private boolean keyboardVisible;
    private boolean restoreKeyboardAfterPicker;
    private View pageEditor;
    private View pageOutput;
    private View pageTerminal;
    private View pageFiles;
    private TextView outputText;
    private TextView outputMeta;
    private TextView summaryTitle;
    private TextView summaryMeta;
    private TextView summaryPill;
    private LinearLayout imagesSection;
    private LinearLayout imageContainer;
    private LinearLayout outputConsoleCard;
    private View outputEmpty;
    private View outputScroll;
    private View runSummaryCard;
    private TextView terminalLog;
    private TextView terminalPath;
    private View terminalScroll;
    private EditText terminalInput;
    private LinearLayout filesContainer;
    private LinearLayout codeKeysRow;
    private EditText filesSearch;

    private PythonEngine engine;
    private TerminalSession terminalSession;
    private ActivityResultLauncher<String[]> filePicker;
    private PickerMode pickerMode = PickerMode.NONE;

    private File currentFile;
    private boolean dirty;
    private boolean loadingEditor;
    private boolean running;
    private int runImageCount;
    private int runCount;

    private final SpannableStringBuilder outputBuffer = new SpannableStringBuilder();
    private final SpannableStringBuilder terminalBuffer = new SpannableStringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        applyWindowInsets();
        bindViews();
        engine = new PythonEngine(this);
        terminalSession = new TerminalSession(this);
        registerPicker();
        setupEditor();
        applySavedSettings();
        setupActions();
        setupNavigation();
        showTerminalWelcome();
        restoreState(savedInstanceState);
        setupBackHandling();
    }

    private void applyWindowInsets() {
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);
        View content = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(content, (view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            Insets ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime());
            boolean imeVisible = windowInsets.isVisible(WindowInsetsCompat.Type.ime());
            keyboardVisible = imeVisible;
            applyKeyboardLayout(imeVisible && selectedPageId == R.id.nav_editor);
            view.setPadding(bars.left, bars.top, bars.right,
                    imeVisible ? ime.bottom : bars.bottom);
            return windowInsets;
        });
        ViewCompat.requestApplyInsets(content);
    }

    private void bindViews() {
        codeEditor = findViewById(R.id.codeEditor);
        gutter = findViewById(R.id.gutter);
        positionLabel = findViewById(R.id.positionLabel);
        fileNameLabel = findViewById(R.id.fileNameLabel);
        fileMetaLabel = findViewById(R.id.fileMetaLabel);
        editorTabLabel = findViewById(R.id.editorTabLabel);
        dirtyDot = findViewById(R.id.dirtyDot);
        runButton = findViewById(R.id.runButton);
        runProgress = findViewById(R.id.runProgress);
        bottomNav = findViewById(R.id.bottomNav);
        topBar = findViewById(R.id.topBar);
        headerSubtitle = findViewById(R.id.headerSubtitle);
        editorActionsRow = findViewById(R.id.editorActionsRow);
        editorStatusRow = findViewById(R.id.editorStatusRow);
        tabEditor = findViewById(R.id.tabEditor);
        tabOutput = findViewById(R.id.tabOutput);
        tabTerminal = findViewById(R.id.tabTerminal);
        tabFiles = findViewById(R.id.tabFiles);
        tabIconEditor = findViewById(R.id.tabIconEditor);
        tabIconOutput = findViewById(R.id.tabIconOutput);
        tabIconTerminal = findViewById(R.id.tabIconTerminal);
        tabIconFiles = findViewById(R.id.tabIconFiles);
        tabLabelEditor = findViewById(R.id.tabLabelEditor);
        tabLabelOutput = findViewById(R.id.tabLabelOutput);
        tabLabelTerminal = findViewById(R.id.tabLabelTerminal);
        tabLabelFiles = findViewById(R.id.tabLabelFiles);
        pageEditor = findViewById(R.id.pageEditor);
        pageOutput = findViewById(R.id.pageOutput);
        pageTerminal = findViewById(R.id.pageTerminal);
        pageFiles = findViewById(R.id.pageFiles);
        outputText = findViewById(R.id.outputText);
        outputMeta = findViewById(R.id.outputMeta);
        summaryTitle = findViewById(R.id.summaryTitle);
        summaryMeta = findViewById(R.id.summaryMeta);
        summaryPill = findViewById(R.id.summaryPill);
        imagesSection = findViewById(R.id.imagesSection);
        imageContainer = findViewById(R.id.imageContainer);
        outputConsoleCard = findViewById(R.id.outputConsoleCard);
        outputEmpty = findViewById(R.id.outputEmpty);
        outputScroll = findViewById(R.id.outputScroll);
        runSummaryCard = findViewById(R.id.runSummaryCard);
        terminalLog = findViewById(R.id.terminalLog);
        terminalPath = findViewById(R.id.terminalPath);
        terminalScroll = findViewById(R.id.terminalScroll);
        terminalInput = findViewById(R.id.terminalInput);
        filesContainer = findViewById(R.id.filesContainer);
        codeKeysRow = findViewById(R.id.codeKeysRow);
        filesSearch = findViewById(R.id.filesSearch);
    }

    private void registerPicker() {
        filePicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null) {
                pickerMode = PickerMode.NONE;
                restoreEditorKeyboardIfNeeded();
                return;
            }
            handlePickedUri(uri);
        });
    }

    private void setupEditor() {
        codeEditor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateGutter();
                if (!loadingEditor) {
                    setDirty(true);
                }
            }
        });
        codeEditor.setSelectionListener((line, column) ->
                positionLabel.setText(String.format(Locale.US, "Ln %d, Col %d", line, column)));
        codeEditor.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) ->
                gutter.setScrollY(scrollY));

        // Import shortcuts live in the top hamburger menu to keep the editor uncluttered.
        setupCodeKeyBar();
        updateEditorHeader();
    }

    private void setupCodeKeyBar() {
        String[][] keys = {
                {"Tab", "    "}, {"()", "PAIR:()"}, {"[]", "PAIR:[]"},
                {"{}", "PAIR:{}"}, {"''", "PAIR:''"}, {"\"\"", "PAIR:\"\""},
                {":", ":"}, {"=", " = "}, {"#", "# "}, {"if", "if "}, {"for", "for "},
                {"def", "def "}, {"return", "return "}, {"print()", "print()"}
        };
        for (String[] key : keys) {
            TextView button = new TextView(this);
            button.setText(key[0]);
            button.setTextSize(11f);
            button.setTextColor(colorOf(R.color.text_dim));
            button.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            button.setGravity(Gravity.CENTER);
            button.setMinWidth(dp(key[0].length() > 3 ? 58 : 42));
            button.setPadding(dp(10), dp(8), dp(10), dp(8));
            button.setBackgroundResource(R.drawable.bg_key_button);
            button.setClickable(true);
            button.setFocusable(true);
            button.setOnClickListener(v -> {
                if (key[1].startsWith("PAIR:")) {
                    String pair = key[1].substring(5);
                    insertPairAtCursor(pair.substring(0, 1), pair.substring(1));
                } else if ("print()".equals(key[1])) {
                    int start = Math.max(0, codeEditor.getSelectionStart());
                    insertTextAtCursor("print()");
                    codeEditor.setSelection(Math.min(start + 6, codeEditor.length()));
                } else {
                    insertTextAtCursor(key[1]);
                }
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.rightMargin = dp(6);
            button.setLayoutParams(params);
            codeKeysRow.addView(button);
        }
    }

    private void insertPairAtCursor(String open, String close) {
        Editable editable = codeEditor.getText();
        if (editable == null) return;
        int start = Math.max(0, Math.min(codeEditor.getSelectionStart(), editable.length()));
        int end = Math.max(start, Math.min(codeEditor.getSelectionEnd(), editable.length()));
        String selected = editable.subSequence(start, end).toString();
        editable.replace(start, end, open + selected + close);
        int cursor = start + open.length() + selected.length();
        codeEditor.setSelection(Math.min(cursor, editable.length()));
        selectPage(R.id.nav_editor);
        codeEditor.requestFocus();
    }

    private void setupActions() {
        runButton.setOnClickListener(v -> runCurrentFile());
        findViewById(R.id.btnEditorSave).setOnClickListener(v -> saveCurrentFile());
        findViewById(R.id.btnFind).setOnClickListener(v -> showFindReplace());
        findViewById(R.id.btnInsertPath).setOnClickListener(v -> pickFile(PickerMode.INSERT_PATH));
        findViewById(R.id.btnInsertPath).setOnLongClickListener(v -> {
            promptForText("Insert any file path", "path", "", value -> {
                if (!value.trim().isEmpty()) {
                    insertPathIntoEditor(value.trim());
                }
            });
            return true;
        });
        findViewById(R.id.btnOverflow).setOnClickListener(this::showOverflowMenu);
        findViewById(R.id.logo).setOnClickListener(v -> showAbout());
        findViewById(R.id.logo).setOnLongClickListener(v -> {
            showPackages();
            return true;
        });

        findViewById(R.id.btnClearOutput).setOnClickListener(v -> clearOutputState());
        findViewById(R.id.btnCopyOutput).setOnClickListener(v -> copyToClipboard("PyStudio output", outputBuffer.toString()));

        findViewById(R.id.btnTerminalSend).setOnClickListener(v -> submitTerminalCommand());
        findViewById(R.id.btnTerminalClear).setOnClickListener(v -> {
            terminalBuffer.clear();
            terminalLog.setText("");
        });
        findViewById(R.id.btnTerminalHelp).setOnClickListener(v -> {
            TerminalSession.Result help = terminalSession.execute("help");
            appendTerminal(help.output, colorOf(R.color.text_dim));
        });
        terminalInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND
                    || actionId == EditorInfo.IME_ACTION_DONE
                    || actionId == EditorInfo.IME_ACTION_GO) {
                submitTerminalCommand();
                return true;
            }
            return false;
        });

        findViewById(R.id.btnNewFile).setOnClickListener(v -> createNewFile());
        findViewById(R.id.btnImportFile).setOnClickListener(v -> pickFile(PickerMode.IMPORT_FILE));
        filesSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshFiles(); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void setupNavigation() {
        tabEditor.setOnClickListener(v -> selectPage(R.id.nav_editor));
        tabOutput.setOnClickListener(v -> selectPage(R.id.nav_output));
        tabTerminal.setOnClickListener(v -> selectPage(R.id.nav_terminal));
        tabFiles.setOnClickListener(v -> selectPage(R.id.nav_files));
        selectPage(R.id.nav_editor);
    }

    private void selectPage(int itemId) {
        if (itemId != R.id.nav_editor && itemId != R.id.nav_output
                && itemId != R.id.nav_terminal && itemId != R.id.nav_files) {
            itemId = R.id.nav_editor;
        }
        selectedPageId = itemId;
        showPage(itemId);
        updateTabAppearance();
        applyKeyboardLayout(keyboardVisible && itemId == R.id.nav_editor);
    }

    private void updateTabAppearance() {
        styleTab(tabEditor, tabIconEditor, tabLabelEditor, selectedPageId == R.id.nav_editor);
        styleTab(tabOutput, tabIconOutput, tabLabelOutput, selectedPageId == R.id.nav_output);
        styleTab(tabTerminal, tabIconTerminal, tabLabelTerminal, selectedPageId == R.id.nav_terminal);
        styleTab(tabFiles, tabIconFiles, tabLabelFiles, selectedPageId == R.id.nav_files);
    }

    private void styleTab(View tab, ImageView icon, TextView label, boolean selected) {
        if (tab == null || icon == null || label == null) return;
        int tint = colorOf(selected ? R.color.accent : R.color.text_faint);
        tab.setBackgroundResource(selected ? R.drawable.bg_tab_selected : R.drawable.bg_tab_idle);
        icon.setColorFilter(tint);
        label.setTextColor(tint);
        label.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
    }

    private void showPage(int itemId) {
        pageEditor.setVisibility(itemId == R.id.nav_editor ? View.VISIBLE : View.GONE);
        pageOutput.setVisibility(itemId == R.id.nav_output ? View.VISIBLE : View.GONE);
        pageTerminal.setVisibility(itemId == R.id.nav_terminal ? View.VISIBLE : View.GONE);
        pageFiles.setVisibility(itemId == R.id.nav_files ? View.VISIBLE : View.GONE);
        if (itemId == R.id.nav_files) {
            refreshFiles();
        } else if (itemId == R.id.nav_terminal) {
            terminalPath.setText("~ " + terminalSession.getDisplayPath());
            scrollTerminalToBottom();
        } else if (itemId == R.id.nav_output && outputScroll != null) {
            outputScroll.post(() -> outputScroll.scrollTo(0, 0));
        }
    }

    private void applyKeyboardLayout(boolean compact) {
        if (bottomNav == null) return;
        bottomNav.setVisibility(compact ? View.GONE : View.VISIBLE);
        if (fileMetaLabel != null) fileMetaLabel.setVisibility(compact ? View.GONE : View.VISIBLE);
        if (editorStatusRow != null) editorStatusRow.setVisibility(compact ? View.GONE : View.VISIBLE);
        if (headerSubtitle != null) headerSubtitle.setVisibility(compact ? View.GONE : View.VISIBLE);
        if (topBar != null) {
            int vertical = dp(compact ? 5 : 10);
            topBar.setPadding(dp(14), vertical, dp(14), vertical);
        }
        if (pageEditor != null) {
            pageEditor.setPadding(dp(12), dp(compact ? 4 : 8), dp(12), 0);
        }
        if (editorActionsRow != null) {
            editorActionsRow.setAlpha(compact ? 0.96f : 1f);
        }
    }

    private void restoreState(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            String path = savedInstanceState.getString("current_file", null);
            File restored = path == null ? null : new File(path);
            if (restored == null || !restored.isFile()) {
                restored = preferredStartFile();
            }
            openFileNow(restored);
            String text = savedInstanceState.getString("editor_text", null);
            if (text != null) {
                loadingEditor = true;
                codeEditor.setText(text);
                loadingEditor = false;
                updateGutter();
            }
            setDirty(savedInstanceState.getBoolean("dirty", false));
            int page = savedInstanceState.getInt("page", R.id.nav_editor);
            selectPage(page == 0 ? R.id.nav_editor : page);
        } else {
            openFileNow(preferredStartFile());
            selectPage(R.id.nav_editor);
        }
    }

    private File preferredStartFile() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String last = prefs.getString(KEY_LAST_FILE, null);
        if (last != null) {
            File candidate = new File(last);
            if (candidate.isFile()) {
                return candidate;
            }
        }
        File hello = new File(Workspace.root(this), "hello.py");
        if (hello.isFile()) {
            return hello;
        }
        List<File> files = Workspace.listFiles(this);
        for (File file : files) {
            if (file.isFile()) {
                return file;
            }
        }
        File fallback = new File(Workspace.root(this), "hello.py");
        try {
            Workspace.write(fallback, "# PyStudio\nprint('Hello, PyStudio!')\n");
        } catch (IOException ignored) {
        }
        return fallback;
    }

    private void openFileNow(File file) {
        if (file == null || !file.isFile()) {
            return;
        }
        try {
            String content = Workspace.read(file);
            loadingEditor = true;
            codeEditor.setText(content);
            codeEditor.setSelection(0);
            loadingEditor = false;
            currentFile = file;
            setDirty(false);
            updateEditorHeader();
            updateGutter();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_LAST_FILE, file.getAbsolutePath()).apply();
        } catch (IOException error) {
            toast("Could not open file: " + error.getMessage());
        }
    }

    private void requestOpenFile(File file) {
        if (dirty) {
            confirmDiscard(() -> openFileNow(file));
        } else {
            openFileNow(file);
        }
    }

    private void confirmDiscard(Runnable action) {
        new AlertDialog.Builder(this)
                .setTitle("Discard unsaved changes?")
                .setMessage("Your current script has changes that have not been saved.")
                .setPositiveButton("Discard", (dialog, which) -> action.run())
                .setNegativeButton("Keep editing", null)
                .show();
    }

    private void setDirty(boolean value) {
        dirty = value;
        dirtyDot.setVisibility(value ? View.VISIBLE : View.GONE);
        updateEditorHeader();
    }

    private void updateEditorHeader() {
        String name = currentFile == null ? "untitled.py" : currentFile.getName();
        fileNameLabel.setText(name);
        editorTabLabel.setText(name);
        String state = dirty ? "unsaved changes" : "saved";
        String size = currentFile != null ? Workspace.formatSize(currentFile.length()) : "new file";
        fileMetaLabel.setText("workspace / " + size + " · " + state);
    }

    private void updateGutter() {
        Editable editable = codeEditor.getText();
        String text = editable == null ? "" : editable.toString();
        int lines = 1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                lines++;
            }
        }
        StringBuilder builder = new StringBuilder(lines * 3);
        for (int i = 1; i <= lines; i++) {
            builder.append(i);
            if (i < lines) {
                builder.append('\n');
            }
        }
        gutter.setText(builder.toString());
        gutter.post(() -> gutter.setScrollY(codeEditor.getScrollY()));
    }

    private boolean saveCurrentFile() {
        if (currentFile == null) {
            promptSaveAs(false);
            return false;
        }
        try {
            Editable editable = codeEditor.getText();
            Workspace.write(currentFile, editable == null ? "" : editable.toString());
            setDirty(false);
            updateEditorHeader();
            toast("Saved " + currentFile.getName());
            return true;
        } catch (IOException error) {
            toast("Could not save: " + error.getMessage());
            return false;
        }
    }

    private void promptSaveAs(boolean runAfter) {
        String suggested = currentFile == null ? "script.py" : currentFile.getName();
        promptForText("Save script as", "filename.py", suggested, value -> {
            String name = value.trim();
            if (name.isEmpty()) {
                return;
            }
            if (!name.endsWith(".py")) {
                name += ".py";
            }
            File target = new File(Workspace.root(this), Workspace.sanitizeName(name));
            if (target.exists() && (currentFile == null || !target.getAbsoluteFile().equals(currentFile.getAbsoluteFile()))) {
                new AlertDialog.Builder(this)
                        .setTitle("Overwrite file?")
                        .setMessage(target.getName() + " already exists in the workspace.")
                        .setPositiveButton("Overwrite", (dialog, which) -> saveAsTo(target, runAfter))
                        .setNegativeButton("Cancel", null)
                        .show();
            } else {
                saveAsTo(target, runAfter);
            }
        });
    }

    private void saveAsTo(File target, boolean runAfter) {
        try {
            Editable editable = codeEditor.getText();
            Workspace.write(target, editable == null ? "" : editable.toString());
            currentFile = target;
            setDirty(false);
            updateEditorHeader();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_LAST_FILE, currentFile.getAbsolutePath()).apply();
            toast("Saved " + target.getName());
            if (runAfter) {
                startRun();
            }
        } catch (IOException error) {
            toast("Could not save: " + error.getMessage());
        }
    }

    private void runCurrentFile() {
        if (engine.isRunning()) {
            toast("A script is already running.");
            return;
        }
        if (currentFile == null) {
            promptSaveAs(true);
            return;
        }
        if (!saveCurrentFile()) {
            return;
        }
        startRun();
    }

    private void startRun() {
        if (engine.isRunning() || currentFile == null) {
            return;
        }
        Editable editable = codeEditor.getText();
        String code = editable == null ? "" : editable.toString();
        String fileName = currentFile.getName();
        hideKeyboard();
        resetRunOutput();
        selectPage(R.id.nav_output);
        updateGutter();
        appendOutput("$ python " + fileName + "\n", colorOf(R.color.text_faint), false);
        setRunningUi(true);
        setSummary("Running " + fileName, "Streaming stdout, stderr and images…", "RUN",
                colorOf(R.color.accent_soft), colorOf(R.color.accent));
        runCount++;
        outputMeta.setText("Run #" + runCount + " · " + fileName);
        engine.run(code, fileName, new PythonEngine.Listener() {
            @Override
            public void onStdout(String text) {
                runOnUiThread(() -> appendOutput(text, colorOf(R.color.text), false));
            }

            @Override
            public void onStderr(String text) {
                runOnUiThread(() -> appendOutput(text, colorOf(R.color.error), false));
            }

            @Override
            public void onImage(String absolutePath) {
                runOnUiThread(() -> addOutputImage(absolutePath, false));
            }

            @Override
            public void onFinished(boolean success, long elapsedMillis) {
                runOnUiThread(() -> finishRun(success, elapsedMillis, false));
            }
        });
    }

    private void runFileInTerminal(File file) {
        if (engine.isRunning()) {
            appendTerminal("A script is already running. Wait for it to finish.\n", colorOf(R.color.error));
            return;
        }
        String code;
        try {
            code = Workspace.read(file);
        } catch (IOException error) {
            appendTerminal("python: " + error.getMessage() + "\n", colorOf(R.color.error));
            return;
        }
        resetRunOutput();
        setRunningUi(true);
        runCount++;
        appendTerminal("$ python " + file.getName() + "\n", colorOf(R.color.text_faint));
        outputMeta.setText("Terminal run #" + runCount + " · " + file.getName());
        engine.run(code, file.getName(), new PythonEngine.Listener() {
            @Override
            public void onStdout(String text) {
                runOnUiThread(() -> appendTerminal(text, colorOf(R.color.text)));
            }

            @Override
            public void onStderr(String text) {
                runOnUiThread(() -> appendTerminal(text, colorOf(R.color.error)));
            }

            @Override
            public void onImage(String absolutePath) {
                runOnUiThread(() -> addOutputImage(absolutePath, true));
            }

            @Override
            public void onFinished(boolean success, long elapsedMillis) {
                runOnUiThread(() -> finishRun(success, elapsedMillis, true));
            }
        });
    }

    private void finishRun(boolean success, long elapsedMillis, boolean terminalTarget) {
        setRunningUi(false);
        String duration = formatDuration(elapsedMillis);
        String images = runImageCount == 1 ? "1 image" : runImageCount + " images";
        String name = currentFile == null ? "script" : currentFile.getName();
        setSummary(success ? "Finished successfully" : "Execution failed",
                name + " · " + duration + " · " + images,
                success ? "OK" : "ERROR",
                success ? colorOf(R.color.accent_soft) : colorOf(R.color.error_soft),
                success ? colorOf(R.color.accent) : colorOf(R.color.error));
        if (outputBuffer.length() == 0) {
            if (success) {
                appendOutput("(script completed without printed output)\n", colorOf(R.color.text_faint), true);
            } else {
                appendOutput("(the interpreter stopped without a traceback)\n", colorOf(R.color.text_faint), true);
            }
        }
        if (terminalTarget) {
            String line = (success ? "exit 0" : "exit 1") + " · " + duration + " · " + images + "\n";
            appendTerminal(line, success ? colorOf(R.color.mint) : colorOf(R.color.error));
            if (runImageCount > 0) {
                appendTerminal("Images are available in the Output tab.\n", colorOf(R.color.text_faint));
            }
        }
        outputMeta.setText((success ? "Completed" : "Failed") + " in " + duration + " · " + images);
    }

    private void setRunningUi(boolean value) {
        running = value;
        runButton.setEnabled(!value);
        runButton.setText(value ? "Running" : "Run");
        runProgress.setVisibility(value ? View.VISIBLE : View.GONE);
    }

    private void resetRunOutput() {
        outputBuffer.clear();
        outputText.setText("");
        imageContainer.removeAllViews();
        imagesSection.setVisibility(View.GONE);
        outputConsoleCard.setVisibility(View.GONE);
        outputEmpty.setVisibility(View.GONE);
        runImageCount = 0;
        if (outputText != null) {
            outputText.setText("");
        }
        outputScroll.post(() -> outputScroll.scrollTo(0, 0));
    }

    private void clearOutputState() {
        outputBuffer.clear();
        outputText.setText("");
        imageContainer.removeAllViews();
        imagesSection.setVisibility(View.GONE);
        outputConsoleCard.setVisibility(View.GONE);
        outputEmpty.setVisibility(View.VISIBLE);
        outputMeta.setText("Text, errors and rendered images");
        runImageCount = 0;
        setSummary("Ready to run", "Press Run to execute your script", "IDLE",
                colorOf(R.color.surface_2), colorOf(R.color.text_dim));
    }

    private void appendOutput(String text, int textColor, boolean italic) {
        if (text == null || text.isEmpty()) {
            return;
        }
        int start = outputBuffer.length();
        outputBuffer.append(text);
        outputBuffer.setSpan(new ForegroundColorSpan(textColor), start, outputBuffer.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (italic) {
            outputBuffer.setSpan(new StyleSpan(Typeface.ITALIC), start, outputBuffer.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (outputBuffer.length() > 400_000) {
            outputBuffer.delete(0, 100_000);
        }
        outputConsoleCard.setVisibility(View.VISIBLE);
        outputEmpty.setVisibility(View.GONE);
        outputText.setText(outputBuffer);
    }

    private void setSummary(String title, String meta, String pill, int pillBackground, int pillColor) {
        summaryTitle.setText(title);
        summaryMeta.setText(meta);
        summaryPill.setText(pill);
        summaryPill.setTextColor(pillColor);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(dp(99));
        drawable.setColor(pillBackground);
        drawable.setStroke(dp(1), colorOf(R.color.stroke));
        summaryPill.setBackground(drawable);
    }

    private void addOutputImage(String path, boolean fromTerminal) {
        File file = new File(path);
        if (!file.isFile()) {
            return;
        }
        Bitmap bitmap = decodeSampled(file, 1600);
        if (bitmap == null) {
            return;
        }
        runImageCount++;
        imagesSection.setVisibility(View.VISIBLE);
        outputEmpty.setVisibility(View.GONE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(10));
        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(14));
        background.setColor(colorOf(R.color.surface));
        background.setStroke(dp(1), colorOf(R.color.stroke));
        card.setBackground(background);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = dp(8);
        card.setLayoutParams(cardParams);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(4), dp(2), dp(4), dp(8));
        ImageView badge = new ImageView(this);
        badge.setImageResource(R.drawable.ic_image);
        badge.setColorFilter(colorOf(R.color.mint));
        header.addView(badge, new LinearLayout.LayoutParams(dp(18), dp(18)));
        TextView title = new TextView(this);
        title.setText("  " + file.getName());
        title.setTextColor(colorOf(R.color.text_dim));
        title.setTextSize(10f);
        title.setTypeface(Typeface.MONOSPACE);
        title.setSingleLine(true);
        header.addView(title, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView tap = new TextView(this);
        tap.setText("tap to enlarge");
        tap.setTextColor(colorOf(R.color.text_faint));
        tap.setTextSize(9f);
        header.addView(tap);
        card.addView(header);

        ImageView image = new ImageView(this);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setImageBitmap(bitmap);
        image.setContentDescription("Rendered Python image");
        image.setOnClickListener(v -> showImageDialog(path));
        card.addView(image, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        imageContainer.addView(card);
        if (fromTerminal) {
            appendTerminal("[image] " + file.getName() + " → Output tab\n", colorOf(R.color.mint));
        }
    }

    private Bitmap decodeSampled(File file, int maxDimension) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        int sample = 1;
        int largest = Math.max(bounds.outWidth, bounds.outHeight);
        while (largest / sample > maxDimension) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try {
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (OutOfMemoryError error) {
            return null;
        }
    }

    private void showImageDialog(String path) {
        Bitmap bitmap = decodeSampled(new File(path), 2400);
        if (bitmap == null) {
            toast("Could not load image");
            return;
        }
        ImageView view = new ImageView(this);
        view.setAdjustViewBounds(true);
        view.setImageBitmap(bitmap);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(view);
        new AlertDialog.Builder(this)
                .setTitle(new File(path).getName())
                .setView(scroll)
                .setPositiveButton("Close", null)
                .setNeutralButton("Copy path", (dialog, which) -> copyToClipboard("Image path", path))
                .show();
    }

    private void submitTerminalCommand() {
        String command = terminalInput.getText().toString().trim();
        terminalInput.setText("");
        if (command.isEmpty()) {
            return;
        }
        if (engine.isRunning()) {
            appendTerminal("A script is running. Wait for it to finish before using Python.\n", colorOf(R.color.error));
            return;
        }
        appendTerminal("pystudio:" + terminalSession.getDisplayPath() + "$ " + command + "\n",
                colorOf(R.color.accent));
        TerminalSession.Result result = terminalSession.execute(command);
        if (result.clear) {
            terminalBuffer.clear();
            terminalLog.setText("");
            return;
        }
        if (!result.output.isEmpty()) {
            appendTerminal(result.output, result.error ? colorOf(R.color.error) : colorOf(R.color.text));
        }
        terminalPath.setText("~ " + terminalSession.getDisplayPath());
        if (result.launchPython && result.pythonFile != null) {
            runFileInTerminal(result.pythonFile);
        }
    }

    private void appendTerminal(String text, int textColor) {
        if (text == null || text.isEmpty()) {
            return;
        }
        int start = terminalBuffer.length();
        terminalBuffer.append(text);
        if (!text.endsWith("\n")) {
            terminalBuffer.append("\n");
        }
        terminalBuffer.setSpan(new ForegroundColorSpan(textColor), start, terminalBuffer.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (terminalBuffer.length() > 300_000) {
            terminalBuffer.delete(0, 80_000);
        }
        terminalLog.setText(terminalBuffer);
        scrollTerminalToBottom();
    }

    private void scrollTerminalToBottom() {
        terminalScroll.post(() -> ((ScrollView) terminalScroll).fullScroll(View.FOCUS_DOWN));
    }

    private void showTerminalWelcome() {
        terminalBuffer.clear();
        terminalBuffer.append("PyStudio 3.0 · CPython 3.10 (Chaquopy)\n");
        terminalBuffer.setSpan(new ForegroundColorSpan(colorOf(R.color.accent)), 0, terminalBuffer.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        appendTerminal("Compact embedded Linux-style shell · everything stays on this phone\n"
                + "Type 'help' for commands. Try: ls · python hello.py · pip list\n\n",
                colorOf(R.color.text_dim));
    }

    private void refreshFiles() {
        filesContainer.removeAllViews();
        TextView pathLabel = findViewById(R.id.filesPathLabel);
        pathLabel.setText(Workspace.root(this).getAbsolutePath());
        String query = filesSearch == null ? "" : filesSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        List<File> files = new ArrayList<>();
        for (File item : Workspace.listFiles(this)) {
            if (query.isEmpty() || item.getName().toLowerCase(Locale.ROOT).contains(query)) {
                files.add(item);
            }
        }
        if (files.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(query.isEmpty()
                    ? "No files yet. Create one with “+ New” or import a file from your phone."
                    : "No files match “" + query + "”. Try another name.");
            empty.setTextColor(colorOf(R.color.text_dim));
            empty.setTextSize(12f);
            empty.setPadding(dp(4), dp(18), dp(4), dp(18));
            filesContainer.addView(empty);
            return;
        }
        for (File file : files) {
            filesContainer.addView(createFileRow(file));
        }
    }

    private View createFileRow(File file) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_row);
        row.setPadding(dp(11), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = dp(8);
        row.setLayoutParams(rowParams);
        row.setClickable(true);
        row.setFocusable(true);

        ImageView icon = new ImageView(this);
        icon.setImageResource(file.isDirectory() ? R.drawable.ic_folder : R.drawable.ic_file);
        icon.setColorFilter(file.isDirectory() ? colorOf(R.color.amber) : colorOf(R.color.mint));
        icon.setBackgroundResource(R.drawable.bg_icon_tile);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, dp(4), 0);
        TextView name = new TextView(this);
        name.setText(file.getName() + (file.isDirectory() ? "/" : ""));
        name.setTextColor(colorOf(R.color.text));
        name.setTextSize(12.5f);
        name.setTypeface(Typeface.MONOSPACE);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        texts.addView(name);
        TextView meta = new TextView(this);
        meta.setText(file.isDirectory() ? "folder" : Workspace.formatSize(file.length()) + " · "
                + Workspace.formatDate(file.lastModified()));
        meta.setTextColor(colorOf(R.color.text_faint));
        meta.setTextSize(9f);
        texts.addView(meta);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView more = new TextView(this);
        more.setText("⋮");
        more.setTextColor(colorOf(R.color.text_dim));
        more.setTextSize(17f);
        more.setGravity(Gravity.CENTER);
        more.setPadding(dp(8), dp(4), dp(8), dp(4));
        more.setOnClickListener(v -> showFileMenu(more, file));
        row.addView(more, new LinearLayout.LayoutParams(dp(34), dp(40)));

        row.setOnClickListener(v -> {
            if (file.isDirectory()) {
                openDirectoryInTerminal(file);
            } else {
                requestOpenFile(file);
            }
        });
        row.setOnLongClickListener(v -> {
            showFileMenu(more, file);
            return true;
        });
        return row;
    }

    private void showFileMenu(View anchor, File file) {
        if (file.isDirectory()) {
            PopupMenu menu = new PopupMenu(this, anchor);
            menu.getMenu().add(0, 1, 0, "Open in terminal");
            menu.getMenu().add(0, 2, 1, "Create script here");
            menu.getMenu().add(0, 3, 2, "Delete folder");
            menu.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == 1) {
                    openDirectoryInTerminal(file);
                } else if (item.getItemId() == 2) {
                    promptForText("New script in " + file.getName(), "script.py", "script.py", value -> {
                        String name = value.trim().endsWith(".py") ? value.trim() : value.trim() + ".py";
                        File target = Workspace.uniqueFile(file, name);
                        try {
                            Workspace.write(target, "# " + target.getName() + "\nprint('Hello from PyStudio')\n");
                            refreshFiles();
                            openFileNow(target);
                            selectPage(R.id.nav_editor);
                        } catch (IOException error) {
                            toast("Could not create file");
                        }
                    });
                } else if (item.getItemId() == 3) {
                    confirmDelete(file);
                }
                return true;
            });
            menu.show();
            return;
        }

        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 1, 0, "Open in editor");
        menu.getMenu().add(0, 2, 1, "Run");
        menu.getMenu().add(0, 3, 2, "Insert path");
        menu.getMenu().add(0, 4, 3, "Rename");
        menu.getMenu().add(0, 5, 4, "Duplicate");
        menu.getMenu().add(0, 6, 5, "Delete");
        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    requestOpenFile(file);
                    selectPage(R.id.nav_editor);
                    return true;
                case 2:
                    if (!file.getName().endsWith(".py")) {
                        toast("Only .py files can be executed");
                        return true;
                    }
                    if (dirty && (currentFile == null || !file.equals(currentFile))) {
                        confirmDiscard(() -> {
                            openFileNow(file);
                            selectPage(R.id.nav_editor);
                            startRun();
                        });
                    } else {
                        openFileNow(file);
                        selectPage(R.id.nav_editor);
                        startRun();
                    }
                    return true;
                case 3:
                    insertPathIntoEditor(file.getAbsolutePath());
                    selectPage(R.id.nav_editor);
                    return true;
                case 4:
                    promptForText("Rename file", "new name", file.getName(), value -> renameFile(file, value));
                    return true;
                case 5:
                    duplicateFile(file);
                    return true;
                case 6:
                    confirmDelete(file);
                    return true;
                default:
                    return false;
            }
        });
        menu.show();
    }

    private void renameFile(File file, String newName) {
        String clean = Workspace.sanitizeName(newName);
        if (clean.equals(file.getName())) {
            return;
        }
        File target = new File(file.getParentFile(), clean);
        if (target.exists()) {
            toast("A file with that name already exists");
            return;
        }
        if (file.renameTo(target)) {
            if (currentFile != null && currentFile.equals(file)) {
                currentFile = target;
                updateEditorHeader();
            }
            refreshFiles();
            toast("Renamed to " + clean);
        } else {
            toast("Could not rename file");
        }
    }

    private void duplicateFile(File file) {
        try {
            File target = Workspace.uniqueFile(file.getParentFile() == null
                    ? Workspace.root(this) : file.getParentFile(), file.getName());
            Workspace.write(target, Workspace.read(file));
            refreshFiles();
            toast("Created " + target.getName());
        } catch (IOException error) {
            toast("Could not duplicate file");
        }
    }

    private void confirmDelete(File file) {
        new AlertDialog.Builder(this)
                .setTitle("Delete?")
                .setMessage(file.getName() + " will be permanently removed from the workspace.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean removed = deleteRecursively(file);
                    if (removed) {
                        if (currentFile != null && currentFile.equals(file)) {
                            currentFile = null;
                            loadingEditor = true;
                            codeEditor.setText("");
                            loadingEditor = false;
                            setDirty(false);
                            updateGutter();
                        }
                        refreshFiles();
                        toast("Deleted " + file.getName());
                    } else {
                        toast("Could not delete file");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private boolean deleteRecursively(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    if (!deleteRecursively(child)) {
                        return false;
                    }
                }
            }
        }
        return file.delete();
    }

    private void openDirectoryInTerminal(File directory) {
        TerminalSession.Result cd = terminalSession.execute("cd \"" + directory.getAbsolutePath() + "\"");
        if (cd.error) {
            toast(cd.output);
            return;
        }
        selectPage(R.id.nav_terminal);
        appendTerminal("pystudio:" + terminalSession.getDisplayPath() + "$ cd " + directory.getName() + "\n",
                colorOf(R.color.accent));
        TerminalSession.Result ls = terminalSession.execute("ls");
        appendTerminal(ls.output, colorOf(R.color.text));
        terminalPath.setText("~ " + terminalSession.getDisplayPath());
    }

    private void createNewFile() {
        promptForText("New Python file", "filename.py", "script.py", value -> {
            String name = value.trim();
            if (name.isEmpty()) {
                return;
            }
            if (!name.endsWith(".py")) {
                name += ".py";
            }
            File target = new File(Workspace.root(this), Workspace.sanitizeName(name));
            if (target.exists()) {
                toast("That file already exists");
                return;
            }
            try {
                Workspace.write(target, "# " + target.getName() + "\n# Created in PyStudio\n\n"
                        + "print('Hello, PyStudio!')\n");
                openFileNow(target);
                selectPage(R.id.nav_editor);
                refreshFiles();
            } catch (IOException error) {
                toast("Could not create file");
            }
        });
    }

    private void pickFile(PickerMode mode) {
        pickerMode = mode;
        restoreKeyboardAfterPicker = mode == PickerMode.INSERT_PATH && keyboardVisible;
        try {
            filePicker.launch(mode == PickerMode.INSERT_PATH
                    ? new String[]{"image/*"} : new String[]{"*/*"});
        } catch (Exception error) {
            restoreKeyboardAfterPicker = false;
            toast("No file manager available");
        }
    }

    private void restoreEditorKeyboardIfNeeded() {
        if (!restoreKeyboardAfterPicker) return;
        restoreKeyboardAfterPicker = false;
        codeEditor.post(() -> {
            codeEditor.requestFocus();
            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (manager != null) {
                manager.showSoftInput(codeEditor, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    private void handlePickedUri(Uri uri) {
        PickerMode mode = pickerMode;
        pickerMode = PickerMode.NONE;
        String displayName = queryDisplayName(uri);
        File destinationDir = mode == PickerMode.INSERT_PATH
                ? Workspace.importsDir(this) : Workspace.root(this);
        File destination = Workspace.uniqueFile(destinationDir, displayName);
        try (InputStream input = getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(destination)) {
            if (input == null) {
                throw new IOException("The provider returned an empty stream");
            }
            byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = input.read(buffer)) > 0) {
                output.write(buffer, 0, read);
            }
            output.flush();
        } catch (Exception error) {
            toast("Could not read the picked file: " + error.getMessage());
            return;
        }

        if (mode == PickerMode.INSERT_PATH) {
            selectPage(R.id.nav_editor);
            insertPathIntoEditor(destination.getAbsolutePath());
            toast("Image copied to imports and its path inserted");
            restoreEditorKeyboardIfNeeded();
        } else {
            refreshFiles();
            toast("Imported " + destination.getName());
        }
    }

    private String queryDisplayName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    name = cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        }
        if (name == null || name.trim().isEmpty()) {
            name = uri.getLastPathSegment();
        }
        return name == null ? "picked_file" : name;
    }

    private void insertPathIntoEditor(String path) {
        Editable editable = codeEditor.getText();
        if (editable == null) {
            return;
        }
        int start = Math.max(0, codeEditor.getSelectionStart());
        int end = Math.max(start, codeEditor.getSelectionEnd());
        start = Math.min(start, editable.length());
        end = Math.min(end, editable.length());
        String quoted = "\"" + path.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
        int[] stringRange = findEnclosingString(editable, start);
        String insertion;
        if (stringRange != null) {
            // cv2.imread("old.png") with the cursor inside the literal:
            // replace the whole literal instead of nesting another string.
            start = stringRange[0];
            end = stringRange[1];
            insertion = quoted;
        } else {
            int probe = start - 1;
            while (probe >= 0 && (editable.charAt(probe) == ' ' || editable.charAt(probe) == '\t')) {
                probe--;
            }
            boolean emptyArgumentStart = probe >= 0 && editable.charAt(probe) == '(';
            boolean insideCall = isInsideParentheses(editable, start);
            insertion = (!emptyArgumentStart && insideCall) ? ", " + quoted : quoted;
        }
        editable.replace(start, end, insertion);
        codeEditor.setSelection(Math.min(start + insertion.length(), editable.length()));
        codeEditor.requestFocus();
        selectPage(R.id.nav_editor);
        toast("Inserted path from the phone");
    }


    /**
     * Returns the inner [start, end) range of a single/double quoted string
     * that contains position, or null if the caret is not inside a literal.
     */
    private int[] findEnclosingString(Editable editable, int position) {
        int lineStart = position;
        while (lineStart > 0 && editable.charAt(lineStart - 1) != '\n') {
            lineStart--;
        }
        char quote = 0;
        int open = -1;
        for (int i = lineStart; i < position; i++) {
            char c = editable.charAt(i);
            if (c == '\\') {
                i++;
                continue;
            }
            if (quote != 0) {
                if (c == quote) {
                    quote = 0;
                    open = -1;
                }
            } else if (c == '\'' || c == '"') {
                quote = c;
                open = i;
            }
        }
        if (quote == 0 || open < 0) {
            return null;
        }
        int close = position;
        while (close < editable.length() && editable.charAt(close) != quote && editable.charAt(close) != '\n') {
            if (editable.charAt(close) == '\\') {
                close++;
            }
            close++;
        }
        if (close >= editable.length() || editable.charAt(close) != quote) {
            return null;
        }
        return new int[]{open + 1, close};
    }

    private boolean isInsideParentheses(Editable editable, int position) {
        int depth = 0;
        boolean inSingle = false;
        boolean inDouble = false;
        for (int i = 0; i < position && i < editable.length(); i++) {
            char c = editable.charAt(i);
            if (c == '\\') {
                i++;
                continue;
            }
            if (inSingle) {
                if (c == '\'') {
                    inSingle = false;
                }
            } else if (inDouble) {
                if (c == '"') {
                    inDouble = false;
                }
            } else if (c == '\'') {
                inSingle = true;
            } else if (c == '"') {
                inDouble = true;
            } else if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth = Math.max(0, depth - 1);
            }
        }
        return depth > 0;
    }

    private void insertTextAtCursor(String text) {
        Editable editable = codeEditor.getText();
        if (editable == null) {
            return;
        }
        int start = Math.max(0, codeEditor.getSelectionStart());
        int end = Math.max(start, codeEditor.getSelectionEnd());
        start = Math.min(start, editable.length());
        end = Math.min(end, editable.length());
        editable.replace(start, end, text);
        codeEditor.setSelection(Math.min(start + text.length(), editable.length()));
        selectPage(R.id.nav_editor);
        codeEditor.requestFocus();
    }

    private void showSnippets() {
        final String[] names = {
                "OpenCV · read and show an image",
                "NumPy · array statistics",
                "Matplotlib · sine wave plot",
                "Pillow · open and show an image",
                "Any file · inspect a picked path",
                "Class with a main guard",
                "Function · type hints and error handling"
        };
        final String[] snippets = {
                "import cv2\n\npath = \"\"\nimage = cv2.imread(path)\nprint('shape:', None if image is None else image.shape)\ncv2.imshow('preview', image)\ncv2.waitKey(0)\ncv2.destroyAllWindows()\n",
                "import numpy as np\n\ndata = np.random.default_rng(42).normal(size=(1000,))\nprint('mean :', data.mean())\nprint('std  :', data.std())\nprint('95%  :', np.percentile(data, [2.5, 97.5]))\n",
                "import matplotlib.pyplot as plt\nimport numpy as np\n\nx = np.linspace(0, 2 * np.pi, 240)\nplt.figure(figsize=(7, 4))\nplt.plot(x, np.sin(x), color='#2bb673', label='sin(x)')\nplt.grid(alpha=0.25)\nplt.legend()\nplt.show()\n",
                "from PIL import Image\n\npath = \"\"\nimg = Image.open(path)\nprint('size:', img.size, 'mode:', img.mode)\nimg.show()\n",
                "import os\n\npath = \"\"\nprint('exists:', os.path.exists(path))\nif os.path.exists(path):\n    print('size  :', os.path.getsize(path), 'bytes')\n",
                "class Greeter:\n    def __init__(self, name: str):\n        self.name = name\n\n    def greet(self) -> str:\n        return f'Hello, {self.name}!'\n\n\nif __name__ == '__main__':\n    print(Greeter('PyStudio').greet())\n",
                "def divide(a: float, b: float) -> float:\n    if b == 0:\n        raise ValueError('b must not be zero')\n    return a / b\n\ntry:\n    print(divide(10, 2))\n    print(divide(1, 0))\nexcept ValueError as error:\n    print('caught:', error)\n"
        };
        new AlertDialog.Builder(this)
                .setTitle("Python snippets")
                .setItems(names, (dialog, which) -> insertTextAtCursor(snippets[which]))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showFindReplace() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), 0);
        EditText find = dialogEditText("Find…");
        EditText replace = dialogEditText("Replace with…");
        layout.addView(find);
        layout.addView(replace, topMargin(dp(8)));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Find & replace")
                .setView(layout)
                .setPositiveButton("Find next", null)
                .setNeutralButton("Replace all", null)
                .setNegativeButton("Close", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String query = find.getText().toString();
                if (query.isEmpty()) {
                    return;
                }
                String text = codeEditor.getText().toString();
                int from = Math.max(0, codeEditor.getSelectionEnd());
                int index = text.indexOf(query, from);
                if (index < 0) {
                    index = text.indexOf(query);
                }
                if (index < 0) {
                    toast("No matches for “" + query + "”");
                } else {
                    codeEditor.setSelection(index, index + query.length());
                    codeEditor.requestFocus();
                }
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                String query = find.getText().toString();
                String replacement = replace.getText().toString();
                if (query.isEmpty()) {
                    return;
                }
                String text = codeEditor.getText().toString();
                int occurrences = countOccurrences(text, query);
                if (occurrences == 0) {
                    toast("No matches to replace");
                    return;
                }
                String updated = text.replace(query, replacement);
                loadingEditor = true;
                codeEditor.setText(updated);
                loadingEditor = false;
                setDirty(true);
                codeEditor.refreshSyntaxHighlighting();
                toast("Replaced " + occurrences + " occurrence" + (occurrences == 1 ? "" : "s"));
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private EditText dialogEditText(String hint) {
        EditText editText = new EditText(this);
        editText.setHint(hint);
        editText.setTextColor(colorOf(R.color.text));
        editText.setHintTextColor(colorOf(R.color.text_faint));
        editText.setTextSize(13f);
        editText.setTypeface(Typeface.MONOSPACE);
        editText.setBackgroundResource(R.drawable.bg_input);
        editText.setPadding(dp(12), dp(10), dp(12), dp(10));
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return editText;
    }

    private int countOccurrences(String text, String query) {
        if (query.isEmpty()) {
            return 0;
        }
        int count = 0;
        int position = 0;
        while ((position = text.indexOf(query, position)) >= 0) {
            count++;
            position += query.length();
        }
        return count;
    }

    private void promptForText(String title, String hint, String initialValue, TextCallback callback) {
        EditText input = dialogEditText(hint);
        input.setText(initialValue);
        input.setSingleLine(true);
        input.selectAll();
        FrameLayout wrapper = new FrameLayout(this);
        wrapper.setPadding(dp(20), dp(4), dp(20), 0);
        wrapper.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(wrapper)
                .setPositiveButton("OK", (dialog, which) -> callback.onText(input.getText().toString()))
                .setNegativeButton("Cancel", null)
                .show();
        input.requestFocus();
    }

    private void showPackages() {
        new AlertDialog.Builder(this)
                .setTitle("Bundled Python packages")
                .setMessage(Workspace.PACKAGES_TEXT + "\n\n"
                        + "These native and pure-Python wheels are compiled into the APK for "
                        + "arm64-v8a and armeabi-v7a. A plain import works offline — no pip step on the phone.\n\n"
                        + "OpenCV is a headless Android build. cv2.imshow() and cv2.waitKey() are "
                        + "emulated and rendered as images in the Output tab.\n\n"
                        + "Android apps use an immutable Chaquopy environment, so new native packages "
                        + "are added in app/build.gradle at build time. The Terminal explains this "
                        + "when you run pip install.")
                .setPositiveButton("Got it", null)
                .show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("PyStudio 3.0.1")
                .setMessage("A complete, offline Python editor and compiler for Android.\n\n"
                        + "• CPython 3.10 via Chaquopy, with NumPy, OpenCV, Matplotlib and Pillow compiled into the APK.\n"
                        + "• Live syntax highlighting, line numbers, snippets, find & replace.\n"
                        + "• Separate Output tab for text, tracebacks and rendered images.\n"
                        + "• Embedded terminal with ls, cd, cat, python, pip and more.\n"
                        + "• Any phone file can be picked and its real sandbox path inserted into the cursor.\n\n"
                        + "Builds are signed with the same permanent release key and an increasing "
                        + "versionCode, so new releases install directly over old ones.")
                .setPositiveButton("Close", null)
                .show();
    }

    private void showOverflowMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        // One tap on the hamburger reveals the import shortcuts directly.
        menu.getMenu().add(0, 11, 0, "Import OpenCV · cv2");
        menu.getMenu().add(0, 12, 1, "Import NumPy");
        menu.getMenu().add(0, 13, 2, "Import Matplotlib");
        menu.getMenu().add(0, 14, 3, "Import Pillow");
        menu.getMenu().add(0, 15, 4, "Import Requests");
        menu.getMenu().add(0, 1, 5, "Save file");
        menu.getMenu().add(0, 2, 6, "Save as…");
        menu.getMenu().add(0, 3, 7, "New file…");
        menu.getMenu().add(0, 4, 8, "Insert any file path…");
        menu.getMenu().add(0, 5, 9, "Import file from phone…");
        menu.getMenu().add(0, 6, 10, "Python snippets");
        menu.getMenu().add(0, 7, 11, "Installed packages");
        menu.getMenu().add(0, 8, 12, "Clear output");
        menu.getMenu().add(0, 9, 13, "About PyStudio");
        menu.getMenu().add(0, 10, 14, "Settings");
        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 11:
                    insertTextAtCursor("import cv2\n");
                    return true;
                case 12:
                    insertTextAtCursor("import numpy as np\n");
                    return true;
                case 13:
                    insertTextAtCursor("import matplotlib.pyplot as plt\n");
                    return true;
                case 14:
                    insertTextAtCursor("from PIL import Image\n");
                    return true;
                case 15:
                    insertTextAtCursor("import requests\n");
                    return true;
                case 1:
                    saveCurrentFile();
                    return true;
                case 2:
                    promptSaveAs(false);
                    return true;
                case 3:
                    createNewFile();
                    return true;
                case 4:
                    promptForText("Insert any file path", "path", "", value -> {
                        if (!value.trim().isEmpty()) {
                            insertPathIntoEditor(value.trim());
                        }
                    });
                    return true;
                case 5:
                    pickFile(PickerMode.IMPORT_FILE);
                    return true;
                case 6:
                    showSnippets();
                    return true;
                case 7:
                    showPackages();
                    return true;
                case 8:
                    clearOutputState();
                    selectPage(R.id.nav_output);
                    return true;
                case 9:
                    showAbout();
                    return true;
                case 10:
                    showSettings();
                    return true;
                default:
                    return false;
            }
        });
        menu.show();
    }

    private void applySavedSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int editorFontSize = prefs.getInt(KEY_EDITOR_FONT_SIZE, 13);
        int consoleFontSize = prefs.getInt(KEY_CONSOLE_FONT_SIZE, 12);
        int indentWidth = prefs.getInt(KEY_INDENT_WIDTH, 4);
        boolean showLineNumbers = prefs.getBoolean(KEY_SHOW_LINE_NUMBERS, true);
        boolean autoIndent = prefs.getBoolean(KEY_AUTO_INDENT, true);
        boolean syntaxHighlighting = prefs.getBoolean(KEY_SYNTAX_HIGHLIGHTING, true);
        boolean wordWrap = prefs.getBoolean(KEY_WORD_WRAP, true);

        codeEditor.setTextSize(TypedValue.COMPLEX_UNIT_SP, editorFontSize);
        String fontFamily = prefs.getString(KEY_EDITOR_FONT_FAMILY, "monospace");
        Typeface editorTypeface = "sans".equals(fontFamily) ? Typeface.create("sans-serif", Typeface.NORMAL)
                : ("serif".equals(fontFamily) ? Typeface.SERIF : Typeface.MONOSPACE);
        codeEditor.setTypeface(editorTypeface);
        codeEditor.setAutoIndentEnabled(autoIndent);
        codeEditor.setIndentWidth(indentWidth);
        codeEditor.setWordWrapEnabled(wordWrap);
        codeEditor.setSyntaxHighlightingEnabled(syntaxHighlighting);
        gutter.setTextSize(TypedValue.COMPLEX_UNIT_SP, editorFontSize);
        gutter.setVisibility(showLineNumbers ? View.VISIBLE : View.GONE);
        outputText.setTextSize(TypedValue.COMPLEX_UNIT_SP, consoleFontSize);
        terminalLog.setTextSize(TypedValue.COMPLEX_UNIT_SP, consoleFontSize);
    }

    private void showSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(8), dp(20), dp(12));

        addSettingsSectionTitle(content, "EDITOR");
        SeekBar editorFont = addSettingsSlider(content, "Code font size", "sp", 10, 24,
                prefs.getInt(KEY_EDITOR_FONT_SIZE, 13));
        SeekBar indent = addSettingsSlider(content, "Indent width", "spaces", 2, 8,
                prefs.getInt(KEY_INDENT_WIDTH, 4));
        String[] fontNames = {"Monospace", "Sans Serif", "Serif"};
        String[] fontValues = {"monospace", "sans", "serif"};
        String[] selectedFont = {prefs.getString(KEY_EDITOR_FONT_FAMILY, "monospace")};
        TextView fontChoice = addSettingsChoice(content, "Editor typeface", fontNames,
                fontValues, selectedFont);
        Switch lineNumbers = addSettingsSwitch(content, "Show line numbers",
                "Display line numbers beside your code", prefs.getBoolean(KEY_SHOW_LINE_NUMBERS, true));
        Switch autoIndent = addSettingsSwitch(content, "Smart indentation",
                "Indent a new line automatically after a colon", prefs.getBoolean(KEY_AUTO_INDENT, true));
        Switch syntax = addSettingsSwitch(content, "Syntax highlighting",
                "Color Python keywords, strings, comments and numbers", prefs.getBoolean(KEY_SYNTAX_HIGHLIGHTING, true));
        Switch wordWrap = addSettingsSwitch(content, "Word wrap",
                "Keep long code lines inside the editor width", prefs.getBoolean(KEY_WORD_WRAP, true));

        addSettingsSectionTitle(content, "OUTPUT AND TERMINAL");
        SeekBar consoleFont = addSettingsSlider(content, "Console font size", "sp", 10, 20,
                prefs.getInt(KEY_CONSOLE_FONT_SIZE, 12));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("PyStudio settings")
                .setView(scroll)
                .setPositiveButton("Save", null)
                .setNeutralButton("Defaults", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                prefs.edit()
                        .putInt(KEY_EDITOR_FONT_SIZE, editorFont.getProgress() + 10)
                        .putInt(KEY_INDENT_WIDTH, indent.getProgress() + 2)
                        .putInt(KEY_CONSOLE_FONT_SIZE, consoleFont.getProgress() + 10)
                        .putString(KEY_EDITOR_FONT_FAMILY, selectedFont[0])
                        .putBoolean(KEY_SHOW_LINE_NUMBERS, lineNumbers.isChecked())
                        .putBoolean(KEY_AUTO_INDENT, autoIndent.isChecked())
                        .putBoolean(KEY_SYNTAX_HIGHLIGHTING, syntax.isChecked())
                        .putBoolean(KEY_WORD_WRAP, wordWrap.isChecked())
                        .apply();
                applySavedSettings();
                toast("Settings saved");
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                editorFont.setProgress(3); // 13 sp
                indent.setProgress(2); // 4 spaces
                consoleFont.setProgress(2); // 12 sp
                selectedFont[0] = "monospace";
                fontChoice.setText("Monospace  ›");
                lineNumbers.setChecked(true);
                autoIndent.setChecked(true);
                syntax.setChecked(true);
                wordWrap.setChecked(true);
            });
        });
        dialog.show();
    }

    private TextView addSettingsChoice(LinearLayout parent, String title,
                                       String[] names, String[] values, String[] selected) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(9), 0, dp(9));

        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(colorOf(R.color.text));
        label.setTextSize(13);
        row.addView(label, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView choice = new TextView(this);
        choice.setTextColor(colorOf(R.color.mint));
        choice.setTextSize(12);
        choice.setTypeface(Typeface.DEFAULT_BOLD);
        choice.setPadding(dp(10), dp(7), dp(10), dp(7));
        choice.setBackgroundResource(R.drawable.bg_tool_button);
        int initial = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(selected[0])) initial = i;
        }
        choice.setText(names[initial] + "  ›");
        choice.setOnClickListener(v -> {
            int current = 0;
            for (int i = 0; i < values.length; i++) {
                if (values[i].equals(selected[0])) current = i;
            }
            new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setSingleChoiceItems(names, current, (dialog, which) -> {
                        selected[0] = values[which];
                        choice.setText(names[which] + "  ›");
                        dialog.dismiss();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
        row.addView(choice);
        parent.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return choice;
    }

    private void addSettingsSectionTitle(LinearLayout parent, String title) {
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(colorOf(R.color.accent));
        label.setTextSize(10);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        lp.bottomMargin = dp(7);
        parent.addView(label, lp);
    }

    private SeekBar addSettingsSlider(LinearLayout parent, String title, String unit,
                                      int min, int max, int current) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(0, dp(4), 0, dp(5));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(colorOf(R.color.text));
        label.setTextSize(13);
        heading.addView(label, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView value = new TextView(this);
        value.setTextColor(colorOf(R.color.mint));
        value.setTextSize(12);
        value.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        heading.addView(value);
        block.addView(heading);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(Math.max(0, Math.min(max - min, current - min)));
        value.setText((seek.getProgress() + min) + " " + unit);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value.setText((progress + min) + " " + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        seekLp.topMargin = dp(2);
        block.addView(seek, seekLp);
        parent.addView(block, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return seek;
    }

    private Switch addSettingsSwitch(LinearLayout parent, String title, String description,
                                     boolean checked) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(7), 0, dp(7));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(colorOf(R.color.text));
        heading.setTextSize(13);
        labels.addView(heading);
        TextView detail = new TextView(this);
        detail.setText(description);
        detail.setTextColor(colorOf(R.color.text_faint));
        detail.setTextSize(10);
        detail.setPadding(0, dp(2), 0, 0);
        labels.addView(detail);
        row.addView(labels, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Switch toggle = new Switch(this);
        toggle.setChecked(checked);
        row.addView(toggle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return toggle;
    }

    private void setupBackHandling() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (selectedPageId != R.id.nav_editor) {
                    selectPage(R.id.nav_editor);
                    return;
                }
                if (dirty) {
                    confirmDiscard(MainActivity.this::finish);
                } else {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("current_file", currentFile == null ? null : currentFile.getAbsolutePath());
        Editable editable = codeEditor.getText();
        outState.putString("editor_text", editable == null ? "" : editable.toString());
        outState.putBoolean("dirty", dirty);
        outState.putInt("page", selectedPageId);
        if (currentFile != null) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_LAST_FILE, currentFile.getAbsolutePath()).apply();
        }
    }

    private void copyToClipboard(String label, String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText(label, text));
            toast("Copied to clipboard");
        }
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus == null) {
            focus = findViewById(android.R.id.content);
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        }
    }

    private String formatDuration(long millis) {
        if (millis < 1000) {
            return millis + " ms";
        }
        return String.format(Locale.US, "%.2f s", millis / 1000.0);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams topMargin(int margin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = margin;
        return params;
    }

    private int colorOf(int resource) {
        return ContextCompat.getColor(this, resource);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private interface TextCallback {
        void onText(String value);
    }
}
