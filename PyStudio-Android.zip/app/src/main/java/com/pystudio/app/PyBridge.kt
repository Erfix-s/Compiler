package com.pystudio.app

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The single point of contact between CPython (running inside the Chaquopy
 * runtime) and the Android UI. Python calls these static methods, so they must
 * stay @JvmStatic — that is how the Chaquopy Java bridge finds them.
 *
 * All callbacks are posted onto the main thread; Python itself never blocks.
 */
object PyBridge {

    const val ROUTE_OUTPUT = 0
    const val ROUTE_TERMINAL = 1

    interface Sink {
        fun onText(stream: String, text: String)
        fun onImage(path: String)
        fun onWaitingInput()
        fun onFinished(exitCode: Int)
    }

    @Volatile
    var sink: Sink? = null

    /** Where stdout/stderr produced by the current run should be rendered. */
    @Volatile
    var route: Int = ROUTE_OUTPUT

    private val mainHandler = Handler(Looper.getMainLooper())
    private var latch: CountDownLatch? = null

    @Volatile
    private var answer: String? = null

    /** Called from Python: sys.stdout / sys.stderr writer. */
    @JvmStatic
    fun emit(stream: String, text: String) {
        val s = sink ?: return
        mainHandler.post { s.onText(stream, text) }
    }

    /** Called from Python when plt.show() or cv2.imshow() produced a picture. */
    @JvmStatic
    fun image(path: String) {
        val s = sink ?: return
        mainHandler.post { s.onImage(path) }
    }

    /**
     * Called from Python by input(). Blocks the interpreter thread until the
     * user types something in the Output tab, then returns it (null = cancelled,
     * which Python turns into EOFError).
     */
    @JvmStatic
    fun input(prompt: String?): String? {
        if (!prompt.isNullOrEmpty()) emit("stdout", prompt)
        val s = sink
        val l = CountDownLatch(1)
        synchronized(this) {
            latch = l
            answer = null
        }
        mainHandler.post { s?.onWaitingInput() }
        return try {
            l.await(300, TimeUnit.SECONDS)
            synchronized(this) { answer }
        } catch (e: InterruptedException) {
            null
        } finally {
            synchronized(this) { latch = null }
        }
    }

    /** UI -> Python: the user pressed «ارسال». */
    fun submit(value: String) {
        synchronized(this) {
            answer = value
            latch?.countDown()
        }
    }

    /** UI -> Python: the user dismissed the input row. */
    fun cancelInput() {
        synchronized(this) {
            answer = null
            latch?.countDown()
        }
    }
}
