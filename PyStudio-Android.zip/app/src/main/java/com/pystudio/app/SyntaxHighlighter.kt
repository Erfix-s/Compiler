package com.pystudio.app

import android.graphics.Typeface
import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan

/**
 * Small, dependency-free Python tokenizer for the editor.
 *
 * Order matters: comments and strings are matched first so that keywords
 * inside them are never coloured again.
 */
object SyntaxHighlighter {

    private val KEYWORDS = setOf(
        "def", "class", "return", "if", "elif", "else", "for", "while", "import",
        "from", "as", "with", "try", "except", "finally", "raise", "pass", "break",
        "continue", "lambda", "global", "nonlocal", "assert", "yield", "del", "in",
        "is", "not", "and", "or", "None", "True", "False", "async", "await", "print",
        "range", "len", "open", "input", "int", "float", "str", "list", "dict",
        "set", "tuple", "type", "self", "cls", "__name__", "__main__"
    )

    private val TOKEN = Regex(
        "(?<comment>#[^\\n]*)" +
            "|(?<string>\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"[^\"\\n]*\"|'[^'\\n]*')" +
            "|(?<number>\\b\\d+(?:\\.\\d+)?\\b)" +
            "|(?<word>[A-Za-z_]\\w*)"
    )

    class ColorSpan(color: Int) : ForegroundColorSpan(color)
    class CommentSpan(color: Int) : ForegroundColorSpan(color)

    private const val COLOR_KEYWORD = 0xFF7FE3D6.toInt()
    private const val COLOR_STRING = 0xFFE0A03C.toInt()
    private const val COLOR_COMMENT = 0xFF6B7683.toInt()
    private const val COLOR_NUMBER = 0xFFE4674F.toInt()
    private const val COLOR_FUNCTION = 0xFFA9C7D8.toInt()

    fun highlight(editable: Editable) {
        // Drop only the spans we own, so IME / selection spans survive.
        val ours = editable.getSpans(0, editable.length, ColorSpan::class.java)
        ours.forEach { editable.removeSpan(it) }
        val comments = editable.getSpans(0, editable.length, CommentSpan::class.java)
        comments.forEach { editable.removeSpan(it) }
        val italics = editable.getSpans(0, editable.length, StyleSpan::class.java)
        italics.forEach { editable.removeSpan(it) }

        if (editable.isEmpty()) return

        for (match in TOKEN.findAll(editable)) {
            val range = match.range
            val start = range.first
            val end = range.last + 1
            if (start >= end || start >= editable.length) continue
            val safeEnd = minOf(end, editable.length)

            val comment = match.groups["comment"]
            val string = match.groups["string"]
            val number = match.groups["number"]
            val word = match.groups["word"]

            when {
                comment != null -> {
                    editable.setSpan(CommentSpan(COLOR_COMMENT), start, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    editable.setSpan(StyleSpan(Typeface.ITALIC), start, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                string != null ->
                    editable.setSpan(ColorSpan(COLOR_STRING), start, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                number != null ->
                    editable.setSpan(ColorSpan(COLOR_NUMBER), start, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                word != null -> {
                    val text = editable.subSequence(start, safeEnd).toString()
                    val color = when {
                        text in KEYWORDS -> COLOR_KEYWORD
                        isCall(editable, safeEnd) -> COLOR_FUNCTION
                        else -> continue
                    }
                    editable.setSpan(ColorSpan(color), start, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }
    }

    private fun isCall(editable: Editable, end: Int): Boolean {
        var i = end
        while (i < editable.length && (editable[i] == ' ' || editable[i] == '\t')) i++
        return i < editable.length && editable[i] == '('
    }

    /** Number of lines, used by the gutter. */
    fun lineCount(text: CharSequence): Int {
        if (text.isEmpty()) return 1
        var lines = 1
        for (i in 0 until text.length) if (text[i] == '\n') lines++
        return lines
    }
}
