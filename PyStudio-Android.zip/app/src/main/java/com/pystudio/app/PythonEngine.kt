package com.pystudio.app

import com.chaquo.python.Python
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Runs Python code on a background thread.
 *
 *  - bootstrap (once per process) redirects stdout/stderr to the UI, points
 *    HOME + cwd at writable storage, adds the runtime site-packages dir to
 *    sys.path and installs lazy patches so that plt.show() and cv2.imshow()
 *    hand their pictures to the Output tab instead of opening a real window
 *    (Android has no GUI window system for those toolkits).
 *  - user code is written to disk and executed with runpy under __name__ ==
 *    "__main__", so `if __name__ == "__main__":` blocks and __file__ work.
 */
object PythonEngine {

    @Volatile
    var running = false

    private val bootstrapped = AtomicBoolean(false)

    fun run(
        code: String,
        asFile: Boolean,
        route: Int,
        workDir: File,
        homeDir: File,
        libsDir: File,
        imgDir: File,
        onDone: (Int) -> Unit
    ) {
        Thread {
            running = true
            PyBridge.route = route
            var status = 0
            try {
                val py = Python.getInstance()
                val builtins = py.getModule("builtins")

                if (!bootstrapped.get()) {
                    builtins.callAttr("exec", bootstrap(homeDir, workDir, libsDir, imgDir))
                    bootstrapped.set(true)
                }

                val program = if (asFile) {
                    val script = File(workDir, "run_${System.currentTimeMillis()}.py")
                    script.parentFile?.mkdirs()
                    script.writeText(code, Charsets.UTF_8)
                    cleanOldScripts(workDir)
                    "import runpy\nrunpy.run_path(${pyQuote(script.absolutePath)}, run_name='__main__')"
                } else {
                    code
                }
                builtins.callAttr("exec", program)
            } catch (t: Throwable) {
                status = 1
                try {
                    Python.getInstance().getModule("builtins").callAttr(
                        "exec",
                        "import traceback\ntraceback.print_exc()"
                    )
                } catch (ignored: Throwable) {
                    PyBridge.emit("stderr", t.toString() + "\n")
                }
            } finally {
                running = false
                val s = status
                android.os.Handler(android.os.Looper.getMainLooper()).post { onDone(s) }
            }
        }.apply {
            name = "pystudio-python"
            start()
        }
    }

    private fun cleanOldScripts(workDir: File) {
        val old = workDir.listFiles { f -> f.name.startsWith("run_") && f.name.endsWith(".py") }
            ?: return
        if (old.size <= 5) return
        old.sortedBy { it.lastModified() }.take(old.size - 5).forEach { it.delete() }
    }

    /** Escape a string as a Python single-quoted literal. */
    fun pyQuote(value: String): String =
        "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"

    private fun bootstrap(home: File, work: File, libs: File, img: File): String = """
import sys, os, io, builtins as _bi
from com.pystudio.app import PyBridge

_PY_HOME = ${pyQuote(home.absolutePath)}
_PY_WORK = ${pyQuote(work.absolutePath)}
_PY_LIBS = ${pyQuote(libs.absolutePath)}
_PY_IMG  = ${pyQuote(img.absolutePath)}

for _d in (_PY_HOME, _PY_WORK, _PY_LIBS, _PY_IMG):
    try:
        os.makedirs(_d, exist_ok=True)
    except Exception:
        pass

os.environ['HOME'] = _PY_HOME
os.environ.setdefault('MPLBACKEND', 'Agg')
try:
    os.chdir(_PY_WORK)
except Exception:
    pass
if _PY_LIBS not in sys.path:
    sys.path.insert(0, _PY_LIBS)

class _PsOut(io.TextIOBase):
    def __init__(self, name):
        self._name = name
        self._buf = ''
    def write(self, s):
        if s:
            try:
                PyBridge.emit(self._name, s)
            except Exception:
                pass
        return len(s)
    def flush(self):
        pass
    @property
    def encoding(self):
        return 'utf-8'
    @property
    def errors(self):
        return 'replace'
    def writable(self):
        return True
    def isatty(self):
        return False

class _PsIn(io.TextIOBase):
    def readline(self, size=-1):
        value = PyBridge.input('')
        if value is None:
            raise EOFError('input() was cancelled')
        return value + '\n'
    def read(self, size=-1):
        raise EOFError('input() is only available line by line on Android')
    def readable(self):
        return False
    def isatty(self):
        return False

def _patch_cv2():
    import sys as _s, os as _o, time as _t
    cv2 = _s.modules.get('cv2')
    if cv2 is None or getattr(cv2, '_PYSTUDIO_PATCHED', False):
        return
    cv2._PYSTUDIO_PATCHED = True
    def _imshow(win, img, *a, **k):
        folder = _o.path.join(_PY_IMG, 'cv2')
        try:
            _o.makedirs(folder, exist_ok=True)
        except Exception:
            pass
        name = 'img_%d_%d.png' % (int(_t.time() * 1000), abs(hash(str(win))) % 100000)
        path = _o.path.join(folder, name)
        cv2.imwrite(path, img)
        PyBridge.image(path)
        return None
    cv2.imshow = _imshow
    cv2.namedWindow = lambda *a, **k: None
    cv2.destroyWindow = lambda *a, **k: None
    cv2.destroyAllWindows = lambda *a, **k: None
    cv2.waitKey = lambda *a, **k: -1
    if hasattr(cv2, 'pollKey'):
        cv2.pollKey = lambda *a, **k: -1

def _patch_mpl():
    import sys as _s, os as _o, time as _t
    plt = _s.modules.get('matplotlib.pyplot')
    if plt is None or getattr(plt, '_PYSTUDIO_PATCHED', False):
        return
    plt._PYSTUDIO_PATCHED = True
    def _show(*a, **k):
        folder = _o.path.join(_PY_IMG, 'mpl')
        try:
            _o.makedirs(folder, exist_ok=True)
        except Exception:
            pass
        try:
            numbers = list(plt.get_fignums())
        except Exception:
            numbers = []
        stamp = int(_t.time() * 1000)
        for index, number in enumerate(numbers):
            figure = plt.figure(number)
            path = _o.path.join(folder, 'figure_%d_%d.png' % (stamp, index))
            try:
                figure.savefig(path, dpi=120, bbox_inches='tight')
                PyBridge.image(path)
            except Exception as exc:
                PyBridge.emit('stderr', 'savefig failed: %s\n' % exc)
        plt.close('all')
    plt.show = _show

if not getattr(_bi, '_PYSTUDIO_BOOT', False):
    _bi._PYSTUDIO_BOOT = True
    sys.stdout = _PsOut('stdout')
    sys.stderr = _PsOut('stderr')
    sys.stdin = _PsIn()
    sys.stderr.reconfigure = getattr(sys.stderr, 'reconfigure', None)

    _orig_import = _bi.__import__
    def _ps_import(name, globals=None, locals=None, fromlist=(), level=0):
        module = _orig_import(name, globals, locals, fromlist, level)
        try:
            if name == 'cv2' or name.startswith('cv2.'):
                _patch_cv2()
            if name == 'matplotlib' or name.startswith('matplotlib.'):
                _patch_mpl()
        except Exception:
            pass
        return module
    _bi.__import__ = _ps_import
    _patch_cv2()
    _patch_mpl()

    PyBridge.emit('stdout', '')
""".trimIndent()
}
