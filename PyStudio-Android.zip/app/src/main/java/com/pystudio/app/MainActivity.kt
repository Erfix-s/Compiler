package com.pystudio.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import java.io.File

class MainActivity : AppCompatActivity(), PyBridge.Sink {

    companion object {
        private val SAMPLE_CODE = """# PyStudio — نمونه اجرا
# cv2.imshow() و plt.show() به صورت عکس در تب «خروجی» نمایش داده می‌شوند.

import numpy as np
import cv2
import matplotlib.pyplot as plt

x = np.linspace(0, 2 * np.pi, 400)
y = np.sin(x)
print("NumPy:", y.shape, y.dtype, "max =", float(np.max(y)))

plt.figure(figsize=(6, 3))
plt.plot(x, y, color="#2FB6A6", linewidth=2)
plt.plot(x, np.cos(x), color="#E0A03C", linewidth=1.5, linestyle="--")
plt.title("sin(x) / cos(x)")
plt.grid(alpha=0.3)
plt.show()

img = np.full((240, 400, 3), (224, 230, 240), dtype=np.uint8)
cv2.rectangle(img, (40, 40), (360, 200), (166, 90, 47), -1)
cv2.putText(img, "PyStudio", (78, 132), cv2.FONT_HERSHEY_SIMPLEX,
            1.2, (30, 33, 12), 3, cv2.LINE_AA)
cv2.imshow("demo", img)

from PIL import Image, ImageDraw
im = Image.new("RGB", (320, 180), "#12433E")
ImageDraw.Draw(im).ellipse((100, 30, 220, 150), fill="#7FE3D6")
im.save("pillow_demo.png")
print("saved pillow_demo.png in", __file__.rsplit("/", 1)[0])
"""
    }

    private lateinit var toolbar: MaterialToolbar
    private lateinit var tabs: TabLayout
    private lateinit var panelEditor: View
    private lateinit var panelOutput: View
    private lateinit var panelTerminal: View

    private lateinit var codeInput: EditText
    private lateinit var lineNumbers: TextView
    private lateinit var editorStatus: TextView

    private lateinit var outScroll: ScrollView
    private lateinit var outStream: LinearLayout
    private lateinit var outputCounter: TextView
    private lateinit var inputRow: LinearLayout
    private lateinit var inText: EditText

    private lateinit var termScroll: ScrollView
    private lateinit var termOut: TextView
    private lateinit var termIn: EditText
    private lateinit var termCwd: TextView

    private lateinit var homeDir: File
    private lateinit var workDir: File
    private lateinit var libsDir: File
    private lateinit var imgDir: File
    private lateinit var terminal: Terminal

    private var documentUri: Uri? = null
    private var documentName = "main.py"
    private var highlightLock = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private val outBuffer = StringBuilder()
    private var outKind = "stdout"
    private var lastOutputView: TextView? = null
    private var lastOutputKind = "stdout"
    private var outputBlocks = 0
    private var emptyState: TextView? = null

    private val openDocLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            if (uri != null && result.resultCode == RESULT_OK) loadDocument(uri)
        }

    private val createDocLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            if (uri != null && result.resultCode == RESULT_OK) {
                documentUri = uri
                documentName = queryName(uri) ?: documentName
                toolbar.subtitle = documentName
                writeDocument(uri)
            }
        }

    private val pickPathLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            if (uri != null && result.resultCode == RESULT_OK) insertPickedFile(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        setContentView(R.layout.activity_main)

        homeDir = filesDir
        workDir = File(homeDir, "workspace").apply { mkdirs() }
        libsDir = File(homeDir, "pylibs").apply { mkdirs() }
        imgDir = File(homeDir, "outputs").apply { mkdirs() }

        toolbar = findViewById(R.id.toolbar)
        panelEditor = findViewById(R.id.panelEditor)
        panelOutput = findViewById(R.id.panelOutput)
        panelTerminal = findViewById(R.id.panelTerminal)
        codeInput = findViewById(R.id.codeInput)
        lineNumbers = findViewById(R.id.lineNumbers)
        editorStatus = findViewById(R.id.editorStatus)
        outScroll = findViewById(R.id.outScroll)
        outStream = findViewById(R.id.outStream)
        outputCounter = findViewById(R.id.outputCounter)
        inputRow = findViewById(R.id.inputRow)
        inText = findViewById(R.id.inText)
        termScroll = findViewById(R.id.termScroll)
        termOut = findViewById(R.id.termOut)
        termIn = findViewById(R.id.termIn)
        termCwd = findViewById(R.id.termCwd)
        tabs = findViewById(R.id.tabs)

        PyBridge.sink = this

        setupTabs()
        setupEditor()
        setupOutput()
        setupTerminal()
        restoreDocument()
        selectPanel(0)
    }

    // ---------------------------------------------------------------- tabs

    private fun setupTabs() {
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) = selectPanel(tab?.position ?: 0)
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun selectPanel(position: Int) {
        panelEditor.visibility = if (position == 0) View.VISIBLE else View.GONE
        panelOutput.visibility = if (position == 1) View.VISIBLE else View.GONE
        panelTerminal.visibility = if (position == 2) View.VISIBLE else View.GONE
    }

    private fun showTab(position: Int) {
        val tab = tabs.getTabAt(position) ?: return
        if (tab.isSelected) selectPanel(position) else tab.select()
    }

    // -------------------------------------------------------------- editor

    private fun setupEditor() {
        codeInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (highlightLock || s == null) return
                highlightLock = true
                SyntaxHighlighter.highlight(s)
                highlightLock = false
                refreshGutter()
            }
        })

        codeInput.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            lineNumbers.translationY = -scrollY.toFloat()
        }

        findViewById<View>(R.id.btnRun).setOnClickListener { runCode() }
        findViewById<View>(R.id.btnSave).setOnClickListener { saveDocument() }
        findViewById<View>(R.id.btnOpen).setOnClickListener { launchOpenDocument() }
        findViewById<View>(R.id.btnInsertFile).setOnClickListener { launchPickPath() }
        findViewById<View>(R.id.btnNew).setOnClickListener { newDocument() }
        findViewById<View>(R.id.btnClear).setOnClickListener { confirmClearCode() }
    }

    private fun refreshGutter() {
        val count = SyntaxHighlighter.lineCount(codeInput.text)
        val builder = StringBuilder()
        for (line in 1..count) {
            builder.append(line)
            if (line != count) builder.append('\n')
        }
        lineNumbers.text = builder.toString()
    }

    private fun restoreDocument() {
        val autosave = File(workDir, "autosave.py")
        val initial = try {
            if (autosave.exists() && autosave.length() > 0) autosave.readText(Charsets.UTF_8) else SAMPLE_CODE
        } catch (e: Exception) {
            SAMPLE_CODE
        }
        codeInput.setText(initial)
        codeInput.setSelection(0)
        refreshGutter()
        toolbar.subtitle = documentName
        editorStatus.setText(R.string.status_ready)
    }

    private fun persistAutosave() {
        try {
            File(workDir, "autosave.py").writeText(codeInput.text.toString(), Charsets.UTF_8)
        } catch (ignored: Exception) {
        }
    }

    override fun onPause() {
        super.onPause()
        persistAutosave()
    }

    private fun runCode() {
        if (PythonEngine.running) {
            toast("یک اجرا در جریان است…")
            return
        }
        persistAutosave()
        showTab(1)
        clearEmptyState()
        appendMeta(">>> اجرای $documentName\n")
        editorStatus.setText(R.string.status_running)

        PythonEngine.run(
            codeInput.text.toString(), true, PyBridge.ROUTE_OUTPUT,
            workDir, homeDir, libsDir, imgDir
        ) { status ->
            appendMeta(
                if (status == 0) ">>> پایان اجرا — بدون خطا\n"
                else ">>> پایان اجرا — خطا (کد $status)\n"
            )
            editorStatus.text =
                if (status == 0) getString(R.string.status_done) else "اجرا با خطا پایان یافت"
            inputRow.visibility = View.GONE
        }
    }

    private fun newDocument() {
        AlertDialog.Builder(this)
            .setTitle("فایل جدید")
            .setMessage("فایل فعلی در فضای داخلی ذخیره خودکار می‌شود. فایل جدید ساخته شود؟")
            .setPositiveButton("بله") { _, _ ->
                persistAutosave()
                documentUri = null
                documentName = "main.py"
                toolbar.subtitle = documentName
                codeInput.setText("")
                refreshGutter()
                toast("فایل جدید ساخته شد")
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun confirmClearCode() {
        if (codeInput.text.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("پاک کردن کد")
            .setMessage("کل محتوای ویرایشگر پاک شود؟")
            .setPositiveButton("پاک کن") { _, _ -> codeInput.setText("") }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------------------------------------------------------- output tab

    private fun setupOutput() {
        emptyState = TextView(this).apply {
            text = getString(R.string.output_empty)
            setTextColor(getColor(R.color.pt_text_secondary))
            textSize = 13f
            setPadding(0, dp(8), 0, dp(8))
        }
        outStream.addView(emptyState)

        findViewById<View>(R.id.btnOutputClear).setOnClickListener {
            outStream.removeAllViews()
            emptyState = null
            lastOutputView = null
            outputBlocks = 0
            outBuffer.setLength(0)
            outputCounter.text = "0"
            emptyState = TextView(this).apply {
                text = getString(R.string.output_empty)
                setTextColor(getColor(R.color.pt_text_secondary))
                textSize = 13f
                setPadding(0, dp(8), 0, dp(8))
            }
            outStream.addView(emptyState)
        }

        findViewById<View>(R.id.btnOutputCopy).setOnClickListener {
            val text = buildString {
                for (i in 0 until outStream.childCount) {
                    val child = outStream.getChildAt(i)
                    if (child is TextView && child !== emptyState) append(child.text)
                }
            }
            if (text.isBlank()) {
                toast("چیزی برای کپی نیست")
            } else {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("PyStudio output", text))
                toast("خروجی کپی شد")
            }
        }
    }

    private fun clearEmptyState() {
        emptyState?.let { outStream.removeView(it) }
        emptyState = null
    }

    private fun appendMeta(text: String) {
        outAppend("meta", text)
    }

    private fun outAppend(stream: String, text: String) {
        if (text.isEmpty()) return
        synchronized(outBuffer) {
            if (outBuffer.isNotEmpty() && stream != outKind) flushOutputLocked()
            outKind = stream
            outBuffer.append(text)
        }
        mainHandler.removeCallbacks(flushOutputRunnable)
        mainHandler.postDelayed(flushOutputRunnable, 60)
    }

    private val flushOutputRunnable = Runnable { flushOutputLocked() }

    private fun flushOutputLocked() {
        val chunk: String
        val kind: String
        synchronized(outBuffer) {
            if (outBuffer.isEmpty()) return
            chunk = outBuffer.toString()
            kind = outKind
            outBuffer.setLength(0)
        }
        clearEmptyState()

        val color = when (kind) {
            "stderr" -> getColor(R.color.pt_error)
            "meta" -> getColor(R.color.pt_text_muted)
            else -> getColor(R.color.pt_text_primary)
        }
        val previous = lastOutputView
        if (previous != null && lastOutputKind == kind && !previous.text.toString().endsWith("\n")) {
            previous.append(chunk)
        } else {
            val view = TextView(this)
            view.typeface = Typeface.MONOSPACE
            view.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12.5f)
            view.setTextColor(color)
            view.setTextIsSelectable(true)
            view.setPadding(0, dp(1), 0, dp(1))
            view.text = chunk
            outStream.addView(view)
            lastOutputView = view
            lastOutputKind = kind
        }
        outputBlocks++
        outputCounter.text = outputBlocks.toString()
        outScroll.post { outScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun outImage(path: String) {
        clearEmptyState()
        val file = File(path)
        val available = resources.displayMetrics.widthPixels - dp(24)

        val image = ImageView(this)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = dp(10)
        params.bottomMargin = dp(2)
        image.layoutParams = params
        image.adjustViewBounds = true
        image.maxHeight = dp(420)
        image.scaleType = ImageView.ScaleType.FIT_CENTER
        image.setBackgroundColor(getColor(R.color.pt_surface))
        image.contentDescription = file.name
        if (file.exists()) decodeScaled(file, available)?.let { image.setImageBitmap(it) }
        outStream.addView(image)

        val caption = TextView(this)
        caption.typeface = Typeface.MONOSPACE
        caption.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f)
        caption.setTextColor(getColor(R.color.pt_text_muted))
        caption.text = "${file.name}  ·  ${file.absolutePath}"
        caption.setPadding(0, dp(3), 0, dp(10))
        outStream.addView(caption)

        lastOutputView = null
        outputBlocks++
        outputCounter.text = outputBlocks.toString()
        outScroll.post { outScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun decodeScaled(file: File, maxWidth: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= maxWidth) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, options)
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: Exception) {
            null
        }
    }

    // -------------------------------------------------------- terminal tab

    private fun setupTerminal() {
        termOut.text = ""
        terminal = Terminal(
            echo = { text, kind -> termAppend(text, kind) },
            clear = { termOut.text = "" },
            runPython = { code -> runPythonSnippet(code) },
            workDir = workDir,
            homeDir = homeDir,
            libsDir = libsDir
        )
        terminal.banner()
        updateCwd()

        findViewById<View>(R.id.termSend).setOnClickListener { submitTerminal() }
        termIn.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                submitTerminal()
                true
            } else false
        }
        inText.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                submitInputRow()
                true
            } else false
        }
        findViewById<View>(R.id.inSend).setOnClickListener { submitInputRow() }
    }

    private fun submitTerminal() {
        val line = termIn.text.toString()
        termIn.setText("")
        terminal.exec(line)
        updateCwd()
        termScroll.post { termScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateCwd() {
        termCwd.text = terminal.cwdLabel()
    }

    private fun runPythonSnippet(code: String) {
        if (PythonEngine.running) {
            termAppend("یک اجرا در جریان است… صبر کنید.\n", Terminal.ERR)
            return
        }
        PythonEngine.run(
            code, false, PyBridge.ROUTE_TERMINAL,
            workDir, homeDir, libsDir, imgDir
        ) { status ->
            termAppend(
                if (status == 0) "process finished\n" else "process exited with code $status\n",
                if (status == 0) Terminal.OK else Terminal.ERR
            )
        }
    }

    private fun termAppend(text: String, kind: Int) {
        if (text.isEmpty()) return
        val color = when (kind) {
            Terminal.ERR -> getColor(R.color.pt_error)
            Terminal.CMD -> getColor(R.color.pt_primary)
            Terminal.OK -> getColor(R.color.pt_accent)
            else -> getColor(R.color.pt_text_primary)
        }
        val builder = SpannableStringBuilder(text)
        builder.setSpan(
            ForegroundColorSpan(color), 0, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        termOut.append(builder)
        termScroll.post { termScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------- PyBridge sink

    override fun onText(stream: String, text: String) {
        if (PyBridge.route == PyBridge.ROUTE_TERMINAL) {
            termAppend(text, if (stream == "stderr") Terminal.ERR else Terminal.OUT)
        } else {
            outAppend(stream, text)
        }
    }

    override fun onImage(path: String) {
        if (PyBridge.route == PyBridge.ROUTE_TERMINAL) {
            termAppend("[image] $path\n", Terminal.OK)
        } else {
            mainHandler.post { outImage(path) }
        }
    }

    override fun onWaitingInput() {
        showTab(1)
        inputRow.visibility = View.VISIBLE
        inText.requestFocus()
        outScroll.post { outScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onFinished(exitCode: Int) {
        inputRow.visibility = View.GONE
    }

    private fun submitInputRow() {
        val value = inText.text.toString()
        inText.setText("")
        inputRow.visibility = View.GONE
        PyBridge.submit(value)
    }

    // ------------------------------------------------- documents + picker

    private fun launchOpenDocument() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("*/*"))
        }
        openDocLauncher.launch(intent)
    }

    private fun launchPickPath() {
        if (!isInsideCall()) {
            toast("مکان نما داخل پارامتر یک تابع نیست — مسیر در محل نوشته می‌شود")
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("*/*"))
        }
        pickPathLauncher.launch(intent)
    }

    private fun saveDocument() {
        val uri = documentUri
        if (uri == null) {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/plain"
                putExtra(Intent.EXTRA_TITLE, documentName)
            }
            createDocLauncher.launch(intent)
        } else {
            writeDocument(uri)
        }
    }

    private fun writeDocument(uri: Uri) {
        try {
            val stream = contentResolver.openOutputStream(uri, "wt")
                ?: contentResolver.openOutputStream(uri)
            if (stream == null) {
                toast("امکان نوشتن در این فایل نیست")
                return
            }
            stream.use { it.write(codeInput.text.toString().toByteArray(Charsets.UTF_8)) }
            documentName = queryName(uri) ?: documentName
            toolbar.subtitle = documentName
            persistAutosave()
            toast("ذخیره شد: $documentName")
        } catch (e: Exception) {
            toast("خطا در ذخیره: ${e.message}")
        }
    }

    private fun loadDocument(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) {
                toast("خطا در باز کردن فایل")
                return
            }
            if (bytes.any { it == 0.toByte() }) {
                toast("این فایل دودویی است و با ویرایشگر متنی باز نمی‌شود")
                return
            }
            documentUri = uri
            documentName = queryName(uri) ?: "untitled.py"
            codeInput.setText(String(bytes, Charsets.UTF_8))
            codeInput.setSelection(0)
            refreshGutter()
            toolbar.subtitle = documentName
            persistAutosave()
            toast("باز شد: $documentName")
        } catch (e: Exception) {
            toast("خطا در باز کردن: ${e.message}")
        }
    }

    /** True when the caret sits after an unclosed "(" on the same line. */
    private fun isInsideCall(): Boolean = findOpenParen(codeInput.text, codeInput.selectionStart) >= 0

    private fun findOpenParen(text: CharSequence, position: Int): Int {
        var depth = 0
        var index = position - 1
        while (index >= 0) {
            val char = text[index]
            if (char == '\n') return -1
            if (char == ')') depth++
            else if (char == '(') {
                if (depth == 0) return index
                depth--
            }
            index--
        }
        return -1
    }

    private fun insertPickedFile(uri: Uri) {
        val target = copyToImports(uri) ?: return
        val editable = codeInput.text
        val position = codeInput.selectionStart.coerceIn(0, editable.length)
        val openIndex = findOpenParen(editable, position)

        val insertion = if (openIndex >= 0) {
            val after = openIndex + 1
            val next = if (after < editable.length) editable[after] else ' '
            if (next == '"' || next == '\'') target.absolutePath
            else "\"${target.absolutePath}\""
        } else {
            "\"${target.absolutePath}\""
        }

        editable.replace(position, position, insertion)
        codeInput.setSelection(position + insertion.length)
        codeInput.requestFocus()
        refreshGutter()
        toast("مسیر درج شد: ${target.name}")
    }

    private fun copyToImports(uri: Uri): File? {
        val folder = File(homeDir, "imports").apply { mkdirs() }
        val raw = queryName(uri) ?: "file_${System.currentTimeMillis()}"
        val base = raw.replace(Regex("[^A-Za-z0-9._-]"), "_")
        var target = File(folder, base)
        var counter = 1
        while (target.exists()) {
            target = File(folder, "${counter}_$base")
            counter++
        }
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            input.use { source -> target.outputStream().use { source.copyTo(it) } }
            target
        } catch (e: Exception) {
            toast("خطا در کپی فایل: ${e.message}")
            null
        }
    }

    private fun queryName(uri: Uri): String? {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) return cursor.getString(index)
                }
            }
        } catch (ignored: Exception) {
        }
        return uri.lastPathSegment
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
