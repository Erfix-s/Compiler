package com.pystudio.app

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A small POSIX-flavoured shell for the Terminal tab.
 *
 * Everything that only needs the filesystem runs directly in Kotlin; anything
 * that needs the interpreter (python, pip) is handed to PythonEngine with the
 * output routed back into this tab.
 */
class Terminal(
    private val echo: (text: String, kind: Int) -> Unit,
    private val clear: () -> Unit,
    private val runPython: (code: String) -> Unit,
    private val workDir: File,
    private val homeDir: File,
    private val libsDir: File
) {

    companion object {
        const val OUT = 0
        const val ERR = 1
        const val CMD = 2
        const val OK = 3
    }

    var cwd: File = workDir
        private set

    private val history = mutableListOf<String>()

    fun banner() {
        echo("PyStudio terminal — دستور help را بزنید.\n", OK)
        echo("python 3.10 (chaquopy) · site-packages: ${libsDir.absolutePath}\n", OUT)
    }

    fun exec(raw: String) {
        val line = raw.trim()
        if (line.isEmpty()) return
        history.add(line)
        echo("\$ $line\n", CMD)

        val parts = line.split(Regex("\\s+"))
        val cmd = parts[0]
        val args = parts.drop(1)

        try {
            when (cmd) {
                "help" -> help()
                "ls" -> ls(args)
                "cd" -> cd(args)
                "pwd" -> echo(cwd.absolutePath + "\n", OUT)
                "cat" -> cat(args)
                "mkdir" -> mkdir(args)
                "rm" -> rm(args)
                "touch" -> touch(args)
                "echo" -> echo(line.removePrefix("echo").trimStart() + "\n", OUT)
                "clear" -> clear()
                "history" -> history.forEachIndexed { i, item -> echo("%3d  %s\n".format(i + 1, item), OUT) }
                "date" -> echo(SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.ENGLISH).format(Date()) + "\n", OUT)
                "whoami" -> echo("android\n", OUT)
                "env", "printenv" -> {
                    echo("HOME=${homeDir.absolutePath}\n", OUT)
                    echo("PWD=${cwd.absolutePath}\n", OUT)
                    echo("TMPDIR=${System.getProperty("java.io.tmpdir")}\n", OUT)
                    echo("PATH=${System.getenv("PATH") ?: "/system/bin"}\n", OUT)
                }
                "python", "python3" -> python(args)
                "pip", "pip3" -> pip(args)
                "about", "neofetch" -> about()
                "uname" -> echo("Linux pystudio-android ${System.getProperty("os.version")} aarch64\n", OUT)
                "exit" -> echo("این ترمینال بخشی از برنامه است و بسته نمی‌شود.\n", ERR)
                else -> echo("command not found: $cmd — برای لیست دستورات help بزنید\n", ERR)
            }
        } catch (t: Throwable) {
            echo((t.message ?: t.toString()) + "\n", ERR)
        }
    }

    private fun help() {
        echo(
            """
            |ls [path]          لیست فایل‌ها
            |cd <path>          رفتن به پوشه
            |pwd                نمایش مسیر جاری
            |cat <file>         نمایش محتوای فایل
            |mkdir <dir>        ساخت پوشه
            |rm [-r] <path>     حذف فایل/پوشه
            |touch <file>       ساخت فایل خالی
            |echo <text>        چاپ متن
            |python <file.py>   اجرای فایل پایتون
            |python -c "<code>" اجرای یک خط کد
            |pip install <pkg>  نصب کتابخانه (از ایندکس Chaquopy / PyPI)
            |pip list           کتابخانه‌های نصب‌شده
            |pip uninstall <pkg>
            |history clear      تاریخچه
            |clear              پاک کردن صفحه
            |
            """.trimMargin(), OUT
        )
    }

    private fun about() {
        echo("PyStudio — Python IDE for Android\n", OK)
        echo("interpreter : CPython 3.10 (Chaquopy)\n", OUT)
        echo("app dir     : ${homeDir.absolutePath}\n", OUT)
        echo("workspace   : ${workDir.absolutePath}\n", OUT)
        echo("packages    : ${libsDir.absolutePath}\n", OUT)
        echo("libraries   : numpy, cv2, matplotlib, pillow (bundled in the APK)\n", OUT)
    }

    private fun ls(args: List<String>) {
        val long = args.any { it.startsWith("-") }
        val target = resolve(args.firstOrNull { !it.startsWith("-") } ?: ".")
        if (!target.exists()) { echo("ls: ${target.name}: no such file or directory\n", ERR); return }
        if (target.isFile) { echo(target.name + "\n", OUT); return }
        val children = target.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
        if (children.isEmpty()) return
        for (child in children) {
            val suffix = if (child.isDirectory) "/" else ""
            if (long) {
                val size = if (child.isFile) child.length() else 0L
                echo("%9d  %s%s\n".format(size, child.name, suffix), if (child.isDirectory) OK else OUT)
            } else {
                echo(child.name + suffix + "  ", if (child.isDirectory) OK else OUT)
            }
        }
        if (!long) echo("\n", OUT)
    }

    private fun cd(args: List<String>) {
        val target = resolve(args.firstOrNull() ?: homeDir.absolutePath)
        if (!target.isDirectory) { echo("cd: ${target.name}: Not a directory\n", ERR); return }
        if (!target.canRead()) { echo("cd: ${target.name}: Permission denied\n", ERR); return }
        cwd = target
    }

    private fun cat(args: List<String>) {
        if (args.isEmpty()) { echo("cat: missing file operand\n", ERR); return }
        val target = resolve(args[0])
        if (!target.exists()) { echo("cat: ${target.name}: No such file or directory\n", ERR); return }
        if (target.isDirectory) { echo("cat: ${target.name}: Is a directory\n", ERR); return }
        val bytes = target.readBytes()
        if (bytes.size > 512 * 1024) { echo("cat: file is larger than 512 KB\n", ERR); return }
        if (bytes.any { it == 0.toByte() }) { echo("cat: binary file\n", ERR); return }
        echo(String(bytes, Charsets.UTF_8), OUT)
        if (!String(bytes, Charsets.UTF_8).endsWith("\n")) echo("\n", OUT)
    }

    private fun mkdir(args: List<String>) {
        val name = args.firstOrNull() ?: run { echo("mkdir: missing operand\n", ERR); return }
        if (resolve(name).mkdirs()) echo("", OUT) else echo("mkdir: cannot create directory '$name'\n", ERR)
    }

    private fun touch(args: List<String>) {
        val name = args.firstOrNull() ?: run { echo("touch: missing file operand\n", ERR); return }
        val file = resolve(name)
        if (file.exists()) file.setLastModified(System.currentTimeMillis())
        else if (file.parentFile?.exists() != false || file.parentFile?.mkdirs() == true) file.writeText("")
        else echo("touch: cannot touch $name\n", ERR)
    }

    private fun rm(args: List<String>) {
        val recursive = args.any { it == "-r" || it == "-rf" || it == "-fr" }
        val name = args.firstOrNull { !it.startsWith("-") } ?: run { echo("rm: missing operand\n", ERR); return }
        val target = resolve(name)
        if (!target.exists()) { echo("rm: ${target.name}: No such file or directory\n", ERR); return }
        if (target.isDirectory && !recursive) { echo("rm: ${target.name}: Is a directory (use -r)\n", ERR); return }
        if (target.deleteRecursively()) echo("", OUT) else echo("rm: failed to remove ${target.name}\n", ERR)
    }

    private fun python(args: List<String>) {
        when {
            args.isEmpty() ->
                echo("Python 3.10 (Chaquopy) — از تب ویرایشگر استفاده کنید یا python file.py بزنید.\n", OK)
            args[0] == "-V" || args[0] == "--version" ->
                echo("Python 3.10.14 (Chaquopy, Android)\n", OUT)
            args[0] == "-c" -> {
                val snippet = args.drop(1).joinToString(" ")
                runPython(snippet)
            }
            else -> {
                val target = resolve(args[0])
                if (!target.exists()) { echo("python: can't open file '${target.name}'\n", ERR); return }
                runPython(
                    "import runpy\nrunpy.run_path(${PythonEngine.pyQuote(target.absolutePath)}, run_name='__main__')"
                )
            }
        }
    }

    private fun pip(args: List<String>) {
        if (args.isEmpty()) {
            echo("usage: pip install <package> | pip list | pip uninstall <package>\n", ERR)
            return
        }
        when (args[0]) {
            "install" -> {
                val pkgs = args.drop(1).filter { !it.startsWith("-") }
                if (pkgs.isEmpty()) { echo("pip: you must give at least one requirement to install\n", ERR); return }
                val list = pkgs.joinToString(", ") { PythonEngine.pyQuote(it) }
                echo("Collecting ${pkgs.joinToString(", ")}\n", OUT)
                runPython("import pystudio_pip\npystudio_pip.main(['install', $list])")
            }
            "list" -> runPython("import pystudio_pip\npystudio_pip.main(['list'])")
            "show" -> {
                val pkgs = args.drop(1)
                val list = pkgs.joinToString(", ") { PythonEngine.pyQuote(it) }
                runPython("import pystudio_pip\npystudio_pip.main(['show', $list])")
            }
            "uninstall" -> {
                val pkgs = args.drop(1).filter { !it.startsWith("-") }
                if (pkgs.isEmpty()) { echo("pip: you must give at least one package to uninstall\n", ERR); return }
                val list = pkgs.joinToString(", ") { PythonEngine.pyQuote(it) }
                runPython("import pystudio_pip\npystudio_pip.main(['uninstall', $list])")
            }
            "-V", "--version" -> echo("pip 24.0 from pystudio_pip (Android build)\n", OUT)
            else -> echo("unknown pip command '${args[0]}'\n", ERR)
        }
    }

    /** Resolve ~, absolute and relative paths against HOME / cwd. */
    fun resolve(raw: String): File {
        var path = raw.trim()
        if (path == "~" || path.startsWith("~/")) path = homeDir.absolutePath + path.removePrefix("~")
        val file = File(path)
        return if (file.isAbsolute) file else File(cwd, path)
    }

    fun cwdLabel(): String {
        val homePath = homeDir.absolutePath
        val current = cwd.absolutePath
        return if (current == homePath) "~"
        else if (current.startsWith(homePath + "/")) "~" + current.removePrefix(homePath)
        else current
    }
}
