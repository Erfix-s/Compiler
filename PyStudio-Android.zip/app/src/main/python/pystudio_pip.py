"""Runtime package manager for PyStudio.

Android cannot ship a complete ``pip``: ``ensurepip`` is unsupported on this
platform and there is no local build toolchain, so ``pip install`` cannot build
from source.  This module implements the useful subset on a phone:

* download a wheel from the Chaquopy Android package index (native packages
  such as numpy / opencv / matplotlib) or from PyPI (pure Python packages),
* unpack it into the app's writable site-packages directory,
* register that directory on ``sys.path`` so a plain ``import`` picks it up,
* resolve ``Requires-Dist`` a few levels deep,
* list and uninstall what is installed.
"""

import json
import os
import re
import shutil
import sys
import tempfile
import urllib.request
import zipfile

CHAQUOPY_INDEX = "https://chaquo.com/pypi-13.1"
PYPI_JSON = "https://pypi.org/pypi/{}/json"
TIMEOUT = 30
MAX_DEPTH = 4


def target_dir():
    """The writable site-packages directory (also added to sys.path)."""
    home = os.environ.get("HOME") or os.getcwd()
    path = os.path.join(home, "pylibs")
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    if path not in sys.path:
        sys.path.insert(0, path)
    return path


def _python_tag():
    return "cp%d%d" % sys.version_info[:2]


def _machine():
    try:
        machine = (os.uname().machine or "").lower()
    except Exception:
        machine = ""
    if machine in ("aarch64", "arm64"):
        return "arm64_v8a"
    if machine.startswith("arm"):
        return "armeabi_v7a"
    if machine == "x86_64":
        return "x86_64"
    if machine in ("x86", "i686", "i386"):
        return "x86"
    return "arm64_v8a"


def _get(url):
    request = urllib.request.Request(url, headers={"User-Agent": "PyStudio/1.0"})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return response.read()


def _wheel_score(filename):
    """Prefer the wheel built for this Python + this CPU, then pure wheels."""
    name = filename.lower()
    if "none-any" in name:
        return 5
    if _python_tag() in name and _machine() in name:
        return 9
    return 0


def _candidates_from_chaquopy(name):
    url = CHAQUOPY_INDEX + "/" + name.lower().replace("_", "-") + "/"
    try:
        page = _get(url).decode("utf-8", "replace")
    except Exception:
        return []
    hrefs = re.findall(r'href="([^"/]+\.whl)"', page)
    scored = [( _wheel_score(h), h) for h in hrefs]
    scored = [item for item in scored if item[0] > 0]
    scored.sort(key=lambda item: -item[0])
    return [url + filename for _score, filename in scored]


def _candidates_from_pypi(name):
    try:
        payload = json.loads(_get(PYPI_JSON.format(name)).decode("utf-8", "replace"))
    except Exception:
        return []
    urls = payload.get("urls") or []
    wheels = [u for u in urls if u.get("packagetype") == "bdist_wheel"]
    scored = [( _wheel_score(u.get("filename", "")), u.get("url")) for u in wheels]
    scored = [item for item in scored if item[0] > 0]
    scored.sort(key=lambda item: -item[0])
    return [url for _score, url in scored if url]


def _installed_names():
    names = set()
    for entry in sys.path:
        if not os.path.isdir(entry):
            continue
        try:
            for child in os.listdir(entry):
                if child.endswith(".dist-info"):
                    names.add(child.rsplit("-", 2)[0].lower().replace("-", "_"))
        except Exception:
            continue
    return names


def _unpack(url, folder):
    handle, temp_path = tempfile.mkstemp(suffix=".whl", dir=folder)
    os.close(handle)
    requires = []
    try:
        data = _get(url)
        with open(temp_path, "wb") as stream:
            stream.write(data)
        with zipfile.ZipFile(temp_path) as archive:
            for member in archive.namelist():
                if member.endswith(".dist-info/METADATA"):
                    text = archive.read(member).decode("utf-8", "replace")
                    for line in text.splitlines():
                        if line.startswith("Requires-Dist:"):
                            requirement = line.split(":", 1)[1].strip()
                            package = re.split(r"[ ;<>=!~(\[]", requirement)[0].strip()
                            if package and not package.startswith("-"):
                                requires.append(package)
                    break
            archive.extractall(folder)
        # Wheels may carry a "<name>-<version>.data" tree: hoist its contents.
        for entry in os.listdir(folder):
            if not entry.endswith(".data"):
                continue
            data_root = os.path.join(folder, entry)
            for sub in ("purelib", "platlib"):
                source = os.path.join(data_root, sub)
                if not os.path.isdir(source):
                    continue
                for item in os.listdir(source):
                    shutil.move(os.path.join(source, item), os.path.join(folder, item))
            shutil.rmtree(data_root, ignore_errors=True)
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass
    return requires


def _install(name, depth, seen, folder):
    key = name.lower().replace("-", "_")
    if key in seen:
        return True
    seen.add(key)
    if key in _installed_names():
        print("Requirement already satisfied: %s" % name)
        return True

    urls = _candidates_from_chaquopy(name) + _candidates_from_pypi(name)
    if not urls:
        print("No Android-compatible wheel found for %s" % name)
        print("Only wheels (no source builds) can be installed on Android.")
        print("Packages with native code must be bundled in app/build.gradle.kts:")
        print('    chaquopy { defaultConfig { pip { install("%s") } } }' % name)
        return False

    url = urls[0]
    print("Downloading %s" % url.rsplit("/", 1)[-1])
    try:
        requires = _unpack(url, folder)
    except Exception as exc:
        print("Failed to install %s: %s" % (name, exc))
        return False
    print("Successfully installed %s" % name)

    if depth < MAX_DEPTH:
        for requirement in requires:
            package = re.split(r"[ ;<>=!~(\[]", requirement)[0].strip()
            if package and package.lower() not in ("python", "pip"):
                _install(package, depth + 1, seen, folder)
    return True


def _dist_infos(folder):
    try:
        return sorted(
            child for child in os.listdir(folder) if child.endswith(".dist-info")
        )
    except Exception:
        return []


def _metadata(path):
    meta = os.path.join(path, "METADATA")
    info = {"Name": os.path.basename(path), "Version": ""}
    if os.path.isfile(meta):
        try:
            with open(meta, "r", encoding="utf-8", errors="replace") as stream:
                for line in stream:
                    if line.startswith("Name:"):
                        info["Name"] = line.split(":", 1)[1].strip()
                    elif line.startswith("Version:"):
                        info["Version"] = line.split(":", 1)[1].strip()
                    elif line.strip() == "":
                        break
        except Exception:
            pass
    return info


def list_packages():
    folder = target_dir()
    printed = set()
    for entry in sys.path:
        if not os.path.isdir(entry):
            continue
        for child in _dist_infos(entry):
            info = _metadata(os.path.join(entry, child))
            key = info["Name"].lower()
            if key in printed:
                continue
            printed.add(key)
            print("%-24s %s" % (info["Name"], info["Version"]))
    print("\n(%d packages · site-packages: %s)" % (len(printed), folder))


def show(names):
    for name in names:
        found = None
        for entry in sys.path:
            if not os.path.isdir(entry):
                continue
            for child in _dist_infos(entry):
                info = _metadata(os.path.join(entry, child))
                if info["Name"].lower().replace("-", "_") == name.lower().replace("-", "_"):
                    found = (entry, info)
                    break
            if found:
                break
        if not found:
            print("WARNING: Package(s) not found: %s" % name)
            continue
        print("Name: %s" % found[1]["Name"])
        print("Version: %s" % found[1]["Version"])
        print("Location: %s" % found[0])


def uninstall(names):
    for name in names:
        key = name.lower().replace("-", "_")
        removed = False
        for entry in sys.path:
            if not os.path.isdir(entry):
                continue
            for child in _dist_infos(entry):
                if child.rsplit("-", 2)[0].lower().replace("-", "_") != key:
                    continue
                record = os.path.join(entry, child, "RECORD")
                if os.path.isfile(record):
                    try:
                        with open(record, "r", encoding="utf-8", errors="replace") as stream:
                            for line in stream:
                                relative = line.split(",", 1)[0].strip()
                                if not relative:
                                    continue
                                victim = os.path.normpath(os.path.join(entry, relative))
                                if victim.startswith(os.path.normpath(entry) + os.sep) and os.path.exists(victim):
                                    try:
                                        os.remove(victim)
                                    except Exception:
                                        pass
                    except Exception:
                        pass
                shutil.rmtree(os.path.join(entry, child), ignore_errors=True)
                removed = True
        print("Successfully uninstalled %s" % name if removed else "WARNING: not installed: %s" % name)


def main(argv=None):
    argv = list(argv or [])
    if not argv:
        print("usage: pip install <package> | pip list | pip show <pkg> | pip uninstall <pkg>")
        return 1
    command = argv[0]
    folder = target_dir()

    if command == "install":
        packages = [item for item in argv[1:] if not item.startswith("-")]
        if not packages:
            print("pip: you must give at least one requirement to install")
            return 1
        failed = []
        for package in packages:
            if not _install(package, 0, set(), folder):
                failed.append(package)
        return 1 if failed else 0

    if command == "list":
        list_packages()
        return 0

    if command == "show":
        show(argv[1:])
        return 0

    if command == "uninstall":
        packages = [item for item in argv[1:] if not item.startswith("-")]
        if not packages:
            print("pip: you must give at least one package to uninstall")
            return 1
        uninstall(packages)
        return 0

    print("unknown pip command: %s" % command)
    return 1
