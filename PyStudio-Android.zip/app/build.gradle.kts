import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

// versionCode is driven by the GitHub Actions run number so every build of the
// ZIP produces a higher versionCode -> installs directly over the previous APK.
// applicationId must never change, otherwise Android treats it as a new app.
val gitRunNumber: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1

android {
    namespace = "com.pystudio.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pystudio.app"
        minSdk = 24
        targetSdk = 36
        versionCode = gitRunNumber
        versionName = "1.0.$gitRunNumber"

        ndk {
            // Python 3.10 supports both 32-bit and 64-bit ABIs.
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        create("release") {
            // Fixed keystore that ships inside the project ZIP: every CI build is
            // signed with the same key, so new APKs install over old ones.
            storeFile = rootProject.file("pystudio.keystore")
            storePassword = "pystudio"
            keyAlias = "pystudio"
            keyPassword = "pystudio"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources {
            excludes += setOf("/META-INF/AL2.0", "/META-INF/LGPL2.1", "/META-INF/DEPENDENCIES")
        }
    }
}

// Chaquopy: CPython plus native (JNI) libraries are bundled into the APK at
// build time, so `import cv2`, `import numpy`, `import matplotlib` and
// `import PIL` all work with a plain import on the phone.
chaquopy {
    defaultConfig {
        version = "3.10"
        pip {
            install("numpy")
            install("opencv-python-headless")
            install("matplotlib")
            install("pillow")
            install("requests")
        }
    }
}

tasks.withType<KotlinCompile>().configureEach {
    compilerOptions.jvmTarget.set(JvmTarget.JVM_17)
}
