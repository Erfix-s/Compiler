PyStudio permanent APK signing material
=======================================

release.pk8        RSA private key (PKCS#8, unencrypted)
release.cert.pem   Self-signed X.509 code-signing certificate, valid until 2126

Both files are intentionally committed so GitHub Actions can sign every build
automatically without repository secrets. The certificate SHA-256 fingerprint is
11:47:79:F2:4A:D8:B4:5E:0D:79:CA:0B:94:9C:4B:94:C9:97:BA:3B:36:7F:C2:06:9C:6B:90:38:7E:4F:92:05

Do not replace or delete them: Android only installs an update over an existing
app when the package name AND the signing certificate are identical. Rotating the
key would require every user to uninstall the app once.

CI signing command (the workflow does this after zipalign):

  apksigner sign \
    --key signing/release.pk8 \
    --cert signing/release.cert.pem \
    --min-sdk-version 26 \
    --out PyStudio.apk aligned.apk

Anyone with access to this public repository can sign an APK that Android will
accept as an update. That is the unavoidable trade-off of a zero-secret,
fully automatic pipeline. If you later want a private key, move it to a GitHub
secret and keep the new key fixed forever.
