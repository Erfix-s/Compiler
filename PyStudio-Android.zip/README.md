# PyStudio — Python IDE for Android

A native Android Python editor/compiler that works fully on-device.

## What is inside

- **Editor** — live Python syntax highlighting, line numbers, snippets, find &
  replace, auto-indentation, save / save as / open, workspace file manager.
- **Run** — CPython 3.10 through Chaquopy. stdout, stderr and tracebacks stream
  live into a dedicated **Output** tab.
- **Images** — `plt.show()`, `cv2.imshow()` and `PIL.Image.show()` are captured
  and rendered as image cards in the Output tab. Text and images never share a
  cramped strip at the bottom of the editor.
- **Terminal** — built-in command interpreter with `ls`, `cd`, `pwd`, `cat`,
  `mkdir`, `touch`, `rm`, `python <file.py>`, `pip list`, `pip install <pkg>`,
  `help`, `clear`, `echo`, `date`, `uname` and more.
- **Phone files** — the **Path** button opens Android's document picker for
  `*/*` (any file, not just images). The file is copied into the app's private
  storage and its real absolute path is inserted at the cursor, inside the call
  parentheses when the cursor is in one (`cv2.imread(|)` → `cv2.imread("/data/…/photo.jpg")`).
- **Bundled library wheels** — NumPy, OpenCV, Matplotlib, Pillow, requests and
  BeautifulSoup are installed by Gradle/Chaquopy at build time and packaged in
  the APK for `arm64-v8a` and `armeabi-v7a`. Plain `import cv2` works offline.

## Build locally

Requirements: JDK 17+, Gradle 9.6.1 or newer, Android SDK Platform 37, Android SDK Build Tools 36.0.0, and Python 3.10
(Chaquopy needs the build interpreter to match the app's Python version).

```bash
export VERSION_CODE=1000001
export VERSION_NAME=2.0.1
gradle :app:assembleRelease
zipalign -p -f 4 app/build/outputs/apk/release/app-release-unsigned.apk aligned.apk
apksigner sign --key signing/release.pk8 --cert signing/release.cert.pem \
  --min-sdk-version 26 --out PyStudio.apk aligned.apk
```

`applicationId` is permanently `com.pystudio.ide`. The GitHub Actions workflow builds an unsigned release APK, aligns it, and signs it using `signing/release.pk8` and `signing/release.cert.pem`. CI injects an increasing
`versionCode` and `versionName`; never change the applicationId or the signing
key if you want in-place updates.

## Honest Android limitations

1. **Runtime `pip install` cannot install arbitrary packages.** Chaquopy builds
   an immutable Python environment into the APK. Native wheels are bundled at
   build time; the terminal reports packages that are already available and
   explains the `chaquopy { pip { … } }` workflow for anything else.
2. **Python 3.10 is intentional.** It is the newest runtime for which Chaquopy's
   repository publishes an Android **OpenCV 4.5.1** wheel. Matplotlib is 3.6.0
   and NumPy is 1.26.2 for ABI compatibility. Newer pure-Python packages can be
   added freely, but cv2 requires this runtime.
3. **`cv2.imshow` has no native window on Android.** It is intercepted and the
   image is displayed in the Output tab; `waitKey` returns immediately.
4. **A content:// URI is not a filesystem path.** OpenCV and Pillow cannot open
   it directly, so PyStudio copies the picked bytes into the app sandbox first
   and inserts that stable absolute path.
5. **No interactive `input()` REPL.** The embedded interpreter streams scripts;
   `input()` raises a helpful error. The terminal is a built-in interpreter, not
   a full Unix process, and sympy/tkinter/etc. are not available.
