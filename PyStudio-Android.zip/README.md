# PyStudio Android — 3.0

PyStudio is an on-device Python workspace for Android, built with Java, Android Views and Chaquopy. It is designed around a phone-first coding workflow: edit, run, inspect output, work with files, and use a lightweight shell without leaving the app.

## Product and UX direction

- **Focused editor first:** the four primary work areas (Editor, Output, Terminal and Files) stay in the top navigation. The Run action remains visible in the application bar.
- **Responsive tools:** editor actions live in a horizontal tool strip so narrow phones do not squeeze the filename and buttons into one row.
- **Mobile coding keys:** a horizontal accessory bar inserts indentation, paired brackets and quotes, punctuation, and common Python keywords. Paired characters keep the cursor between the pair and wrap selected text when applicable.
- **Readable dark workspace:** a midnight-navy surface palette with violet primary actions and cyan support accents separates the editor, console and navigation without excessive decoration.
- **Preferences that persist:** editor and console font sizes, editor typeface, indentation width, line numbers, auto-indent, syntax highlighting and word wrap are saved with Android SharedPreferences.
- **Findable project files:** the Files view has live filename filtering, along with create, import, rename, duplicate and delete actions.

## Main features

- CPython 3.10 running on the device through Chaquopy.
- Bundled NumPy, OpenCV, Matplotlib, Pillow, Requests and BeautifulSoup.
- Live Python syntax highlighting, line numbers, automatic indentation, configurable tab width and word wrap.
- Find and replace, code snippets, quick package imports and path insertion from Android's document picker.
- Run scripts on a worker thread; stream standard output and errors; render Matplotlib/OpenCV/Pillow images in Output.
- Embedded workspace terminal with file navigation and Python execution helpers.
- Private app workspace; no broad storage permission is requested.

## Build

The project is built by the repository's GitHub Actions workflow. The release job injects the increasing version code/name and signs the APK using the repository's release key. Python packages with native components are packaged at build time.

## Notes

The code-key strip and editor toolbar are horizontally scrollable by design for small screens. The bundled runtime remains offline after installation; installing new native Python packages requires rebuilding the APK.


## 3.0.1 Mobile editor layout and keyboard update

- Replaced the icon-only top navigation with compact labelled tabs.
- Hides secondary navigation and status details while the editor keyboard is open, leaving more vertical space for code.
- Moved bundled import shortcuts into the top hamburger menu.
- Replaced the large path action with a small image-picker button. Selecting an image copies it into the app imports folder and inserts its quoted path at the cursor.
