"""PyStudio helpers.

    from studio import images, show

images()       -> image files inside your working folder (set it in the Files tab)
show(x, name)  -> send an RGB image / NumPy array / file path to the Results tab

cv2.imshow() works as usual: PyStudio redirects it to the Results tab.
"""
import contextlib
import io
import json
import linecache
import os
import re
import sys
import traceback

_OUT = ""
_n = 0
_titles = {}
_EXT = (".png", ".jpg", ".jpeg", ".jfif", ".webp", ".bmp", ".gif", ".tif", ".tiff")


def setup(out_dir):
    global _OUT
    _OUT = out_dir
    os.makedirs(_OUT, exist_ok=True)


def images():
    try:
        d = os.getcwd()
        names = os.listdir(d)
    except OSError:
        return []
    return sorted(os.path.join(d, f) for f in names if f.lower().endswith(_EXT))


def show(obj, title=None):
    global _n
    from PIL import Image

    if isinstance(obj, str):
        obj = Image.open(obj)
    elif not isinstance(obj, Image.Image):
        import numpy as np

        a = np.asarray(obj)
        if a.dtype != np.uint8:
            a = np.clip(a, 0, 255).astype(np.uint8)
        if a.ndim == 3 and a.shape[2] == 1:
            a = a[:, :, 0]
        obj = Image.fromarray(a)

    name = re.sub(r"[^\w\-]+", "_", str(title if title else "image")).strip("_")[:40] or "image"
    if title and title in _titles:          # same window title -> update that window
        path = _titles[title]
    else:
        _n += 1
        path = os.path.join(_OUT, "%02d_%s.png" % (_n, name))
        if title:
            _titles[title] = path
    obj.save(path)
    return path


def _patch_cv2():
    """opencv-python-headless has no windows, so route imshow to the Results tab."""
    try:
        import cv2
        import numpy as np
    except Exception:
        return

    def imshow(title, img):
        a = np.asarray(img)
        if a.dtype.kind == "f":
            a = a * 255.0
        elif a.dtype == np.uint16:
            a = a // 256
        if a.ndim == 3 and a.shape[2] in (3, 4):
            a = np.clip(a, 0, 255).astype(np.uint8)
            code = cv2.COLOR_BGR2RGB if a.shape[2] == 3 else cv2.COLOR_BGRA2RGBA
            a = cv2.cvtColor(a, code)
        show(a, title)

    def _noop(*args, **kwargs):
        return None

    cv2.imshow = imshow
    cv2.waitKey = lambda *args, **kwargs: -1
    cv2.waitKeyEx = cv2.waitKey
    for n in ("destroyAllWindows", "destroyWindow", "namedWindow",
              "moveWindow", "resizeWindow", "setWindowTitle"):
        setattr(cv2, n, _noop)


def info():
    import platform

    parts = ["Python " + platform.python_version()]
    for mod, label in (("numpy", "NumPy"), ("PIL", "Pillow"), ("cv2", "OpenCV")):
        try:
            m = __import__(mod)
            parts.append((label + " " + str(getattr(m, "__version__", ""))).strip())
        except Exception:
            pass
    return "  \u00b7  ".join(parts)


def run(code, cwd=""):
    global _n
    _n = 0
    _titles.clear()
    for f in os.listdir(_OUT):
        try:
            os.remove(os.path.join(_OUT, f))
        except OSError:
            pass
    if cwd and os.path.isdir(cwd):
        os.chdir(cwd)                       # relative file names work like on a PC
        if cwd not in sys.path:
            sys.path.insert(0, cwd)
    _patch_cv2()

    buf = io.StringIO()
    err = ""
    ok = True
    linecache.cache["<editor>"] = (len(code), None, code.splitlines(True), "<editor>")
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(code, "<editor>", "exec"), {"__name__": "__main__"})
        except SystemExit:
            pass
        except BaseException:
            ok = False
            et, ev, tb = sys.exc_info()
            err = "".join(traceback.format_exception(et, ev, tb.tb_next))
    return json.dumps({"ok": ok, "out": buf.getvalue(), "err": err})
