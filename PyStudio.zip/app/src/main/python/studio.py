"""PyStudio helpers.  In your scripts:

    from studio import images, show

images()  -> list of file paths for every photo you added in the Images tab
show(x)   -> send a PIL image, a NumPy array (0-255) or a file path to the Results tab
"""
import contextlib
import io
import json
import linecache
import os
import sys
import traceback

_IN = ""
_OUT = ""
_n = 0
_EXT = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff")


def setup(in_dir, out_dir):
    global _IN, _OUT
    _IN, _OUT = in_dir, out_dir
    os.makedirs(_IN, exist_ok=True)
    os.makedirs(_OUT, exist_ok=True)


def images():
    return sorted(
        os.path.join(_IN, f) for f in os.listdir(_IN) if f.lower().endswith(_EXT)
    )


def show(obj):
    global _n
    from PIL import Image

    if isinstance(obj, str):
        obj = Image.open(obj)
    elif not isinstance(obj, Image.Image):
        import numpy as np

        a = np.asarray(obj)
        if a.dtype != np.uint8:
            a = np.clip(a, 0, 255).astype(np.uint8)
        if a.ndim == 3 and a.shape[2] == 1:
            a = a[:, :, 0]
        obj = Image.fromarray(a)
    _n += 1
    path = os.path.join(_OUT, "result_%02d.png" % _n)
    obj.save(path)
    return path


def info():
    import platform

    parts = ["Python " + platform.python_version()]
    for mod, label in (("numpy", "NumPy"), ("PIL", "Pillow"), ("cv2", "OpenCV")):
        try:
            m = __import__(mod)
            parts.append((label + " " + str(getattr(m, "__version__", ""))).strip())
        except Exception:
            pass
    return "  \u00b7  ".join(parts)


def run(code):
    global _n
    _n = 0
    for f in os.listdir(_OUT):
        try:
            os.remove(os.path.join(_OUT, f))
        except OSError:
            pass
    buf = io.StringIO()
    err = ""
    ok = True
    linecache.cache["<editor>"] = (len(code), None, code.splitlines(True), "<editor>")
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(code, "<editor>", "exec"), {"__name__": "__main__"})
        except SystemExit:
            pass
        except BaseException:
            ok = False
            et, ev, tb = sys.exc_info()
            err = "".join(traceback.format_exception(et, ev, tb.tb_next))
    return json.dumps({"ok": ok, "out": buf.getvalue(), "err": err})
