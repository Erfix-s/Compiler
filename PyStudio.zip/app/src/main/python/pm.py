"""Tiny package installer for PyStudio.

Installs pure-Python wheels from PyPI into a private folder that is on sys.path.
Packages with native code (scipy, pandas, ...) cannot be installed at runtime;
numpy, Pillow and OpenCV are already built into the app.
"""
import ast
import hashlib
import io
import json
import os
import re
import shutil
import sys
import urllib.error
import urllib.request
import zipfile

SITE = ""
_PYVER = "%d.%d" % sys.version_info[:2]
BUNDLED = {  # distribution name -> version that ships inside the APK
    "numpy": "1.26.2",
    "pillow": "11.0.0",
    "opencv-python-headless": "4.5.1",
    "opencv-python": "4.5.1",
}


def setup(site):
    global SITE
    SITE = site
    os.makedirs(os.path.join(site, ".pystudio"), exist_ok=True)
    if site not in sys.path:
        sys.path.append(site)


# ---------------------------------------------------------------- versions
def _norm(n):
    return re.sub(r"[-_.]+", "-", n).lower()


def _vkey(v):
    m = re.match(r"\d+(?:\.\d+)*", str(v).strip())
    return tuple(int(x) for x in m.group(0).split(".")) if m else (0,)


def _cmp(a, b):
    n = max(len(a), len(b))
    a = a + (0,) * (n - len(a))
    b = b + (0,) * (n - len(b))
    return (a > b) - (a < b)


def _satisfies(ver, spec):
    for part in [p.strip() for p in str(spec).split(",") if p.strip()]:
        m = re.match(r"(===|==|!=|~=|<=|>=|<|>)\s*(.+)$", part)
        if not m:
            continue
        op, v = m.groups()
        v = v.strip()
        if v.endswith(".*"):
            pre = _vkey(v[:-2])
            hit = _vkey(ver)[: len(pre)] == pre
            if (op == "==" and not hit) or (op == "!=" and hit):
                return False
            continue
        c = _cmp(_vkey(ver), _vkey(v))
        if op in ("==", "===") and c != 0:
            return False
        if op == "!=" and c == 0:
            return False
        if op == ">=" and c < 0:
            return False
        if op == "<=" and c > 0:
            return False
        if op == ">" and c <= 0:
            return False
        if op == "<" and c >= 0:
            return False
        if op == "~=":
            base = _vkey(v)
            keep = base[:-1] if len(base) > 1 else base
            if c < 0 or _vkey(ver)[: len(keep)] != keep:
                return False
    return True


# ---------------------------------------------------------------- markers
_TOKS = re.compile(
    r"\(|\)|\band\b|\bor\b|\bnot\s+in\b|\bin\b|===|==|!=|<=|>=|~=|<|>"
    r"|\"[^\"]*\"|'[^']*'|[A-Za-z_][A-Za-z0-9_.]*"
)


def _env():
    import platform

    return {
        "python_version": _PYVER,
        "python_full_version": platform.python_version(),
        "os_name": "posix",
        "sys_platform": sys.platform,
        "platform_system": "Linux",
        "platform_machine": platform.machine(),
        "platform_release": "",
        "platform_version": "",
        "implementation_name": "cpython",
        "platform_python_implementation": "CPython",
        "extra": "",
    }


def _marker(expr):
    env = _env()
    toks = _TOKS.findall(expr)
    pos = [0]

    def peek():
        return toks[pos[0]] if pos[0] < len(toks) else None

    def nxt():
        t = peek()
        pos[0] += 1
        return t

    def operand():
        t = nxt()
        return t[1:-1] if t[0] in "\"'" else env.get(t, "")

    def compare(a, op, b):
        if op == "in":
            return a in b
        if op.startswith("not"):
            return a not in b
        is_ver = re.fullmatch(r"\d+(\.\d+)*", a) and re.fullmatch(r"\d+(\.\d+)*", b)
        if op in ("==", "===", "!=") and not is_ver:
            return (a == b) == (op != "!=")
        return _satisfies(a, op + b)

    def atom():
        if peek() == "(":
            nxt()
            v = orx()
            nxt()
            return v
        a = operand()
        op = nxt()
        b = operand()
        return compare(a, op, b)

    def andx():
        v = atom()
        while peek() == "and":
            nxt()
            r = atom()
            v = v and r
        return v

    def orx():
        v = andx()
        while peek() == "or":
            nxt()
            r = andx()
            v = v or r
        return v

    try:
        return bool(orx())
    except Exception:
        return True


_REQ = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*(?:\[[^\]]*\])?\s*(.*)$")


def _parse_req(s):
    marker = ""
    if ";" in s:
        s, marker = s.split(";", 1)
    if "@" in s:
        return None
    m = _REQ.match(s)
    if not m:
        return None
    return m.group(1), m.group(2).strip().strip("()").replace(" ", ""), marker.strip()


# ---------------------------------------------------------------- PyPI
def _get(url, accept=None):
    headers = {"User-Agent": "PyStudio"}
    if accept:
        headers["Accept"] = accept
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read()


def _pure(fn):
    parts = fn[:-4].split("-")
    if len(parts) < 5:
        return False
    py, abi, plat = parts[-3:]
    if abi != "none" or plat != "any":
        return False
    for t in py.split("."):
        if t == "py3":
            return True
        m = re.fullmatch(r"py3(\d+)", t)
        if m and int(m.group(1)) <= int(_PYVER.split(".")[1]):
            return True
    return False


_REL = re.compile(r"^\d+(\.\d+)*(\.post\d+)?$")


def _pick(name, spec):
    """Best pure-Python wheel for name/spec -> (version, file) or (None, saw_native)."""
    data = json.loads(
        _get(
            "https://pypi.org/simple/%s/" % _norm(name),
            "application/vnd.pypi.simple.v1+json",
        )
    )
    best, native = None, False
    for f in data.get("files", []):
        fn = f.get("filename", "")
        if not fn.endswith(".whl") or f.get("yanked"):
            continue
        parts = fn[:-4].split("-")
        if len(parts) < 5:
            continue
        ver = parts[1]
        if not _REL.match(ver) or not _satisfies(ver, spec):
            continue
        if not _pure(fn):
            native = True
            continue
        rp = f.get("requires-python")
        if rp and not _satisfies(_PYVER, rp.replace(" ", "")):
            continue
        if best is None or _cmp(_vkey(ver), _vkey(best[0])) > 0:
            best = (ver, f)
    return best if best else (None, native)


def _requires(data):
    txt = ""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for n in z.namelist():
            if n.count("/") == 1 and n.endswith(".dist-info/METADATA"):
                txt = z.read(n).decode("utf-8", "replace")
                break
    out = []
    for line in txt.splitlines():
        if not line.strip():
            break
        if line.startswith("Requires-Dist:"):
            out.append(line.split(":", 1)[1].strip())
    return out


# ---------------------------------------------------------------- local state
def _meta(n):
    return os.path.join(SITE, ".pystudio", n + ".json")


def _load(n):
    try:
        with open(_meta(n)) as fh:
            return json.load(fh)
    except Exception:
        return None


def installed():
    out = []
    d = os.path.join(SITE, ".pystudio")
    for fn in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if fn.endswith(".json"):
            m = _load(fn[:-5])
            if m:
                out.append([m["name"], m["version"]])
    return json.dumps(out)


def _have(n):
    if n in BUNDLED:
        return BUNDLED[n]
    m = _load(n)
    return m["version"] if m else None


def _unpack(n, name, ver, data):
    _remove(n)
    files = []
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for info in z.infolist():
            rel = info.filename
            top = rel.split("/")[0]
            if top.endswith(".data"):
                p = rel.split("/", 2)
                if len(p) < 3 or p[1] not in ("purelib", "platlib"):
                    continue
                rel = p[2]
            target = os.path.normpath(os.path.join(SITE, rel))
            if not target.startswith(SITE + os.sep):
                continue
            if info.is_dir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(info) as src, open(target, "wb") as out:
                out.write(src.read())
            files.append(os.path.relpath(target, SITE))
    with open(_meta(n), "w") as fh:
        json.dump({"name": name, "version": ver, "files": files}, fh)
    import importlib

    importlib.invalidate_caches()


def _remove(n):
    m = _load(n)
    if not m:
        return False
    dirs = set()
    for rel in m["files"]:
        p = os.path.join(SITE, rel)
        try:
            os.remove(p)
        except OSError:
            pass
        d = os.path.dirname(p)
        while d.startswith(SITE + os.sep):
            dirs.add(d)
            d = os.path.dirname(d)
    for d in sorted(dirs, key=len, reverse=True):
        shutil.rmtree(os.path.join(d, "__pycache__"), ignore_errors=True)
        try:
            os.rmdir(d)
        except OSError:
            pass
    try:
        os.remove(_meta(n))
    except OSError:
        pass
    return True


# ---------------------------------------------------------------- install
def _install_one(req, log, seen, top=False):
    p = _parse_req(req)
    if not p:
        raise ValueError("Cannot understand '%s'" % req)
    name, spec, marker = p
    if marker and not _marker(marker):
        return
    n = _norm(name)
    if n in seen:
        return
    seen.add(n)
    have = _have(n)
    if n in BUNDLED:
        if _satisfies(have, spec):
            if top:
                log("%s is built into PyStudio (%s)" % (name, have))
            return
        raise RuntimeError("%s%s is required but PyStudio ships %s" % (name, spec, have))
    if have and _satisfies(have, spec):
        if top:
            log("%s %s is already installed" % (name, have))
        return
    log("Looking up %s%s ..." % (name, spec))
    try:
        ver, f = _pick(name, spec)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise RuntimeError("'%s' was not found on PyPI" % name)
        raise
    if ver is None:
        if f:  # f is the 'saw native wheels' flag here
            raise RuntimeError(
                "'%s' contains native code, so it can't be installed at runtime" % name
            )
        raise RuntimeError("No compatible pure-Python release of '%s' was found" % name)
    log("Downloading %s %s ..." % (name, ver))
    data = _get(f["url"])
    want = (f.get("hashes") or {}).get("sha256")
    if want and hashlib.sha256(data).hexdigest() != want:
        raise RuntimeError("Download of '%s' is corrupted, try again" % name)
    for d in _requires(data):
        _install_one(d, log, seen)
    _unpack(n, name, ver, data)
    log("Installed %s %s" % (name, ver))


def uninstall(name, sink):
    n = _norm(name)
    if _remove(n):
        sink.accept("Removed %s" % name)
        return json.dumps({"ok": True})
    sink.accept("%s is not installed" % name)
    return json.dumps({"ok": False})


# ---------------------------------------------------------------- auto-install on import
_STD = set(getattr(sys, "stdlib_module_names", ()))
_FAILED = set()
ALIASES = {  # import name -> PyPI name, when they differ
    "yaml": "pyyaml", "bs4": "beautifulsoup4", "dateutil": "python-dateutil",
    "dotenv": "python-dotenv", "jwt": "pyjwt", "attr": "attrs", "docx": "python-docx",
    "pptx": "python-pptx", "serial": "pyserial", "git": "gitpython",
    "telegram": "python-telegram-bot", "Crypto": "pycryptodome", "OpenSSL": "pyopenssl",
    "sklearn": "scikit-learn", "skimage": "scikit-image", "magic": "python-magic",
    "slugify": "python-slugify",
}


def _catches_import(h):
    t = h.type
    if t is None:
        return True
    if isinstance(t, ast.Tuple):
        names = [e.id for e in t.elts if isinstance(e, ast.Name)]
    elif isinstance(t, ast.Name):
        names = [t.id]
    else:
        names = []
    return any(n in ("ImportError", "ModuleNotFoundError", "Exception", "BaseException") for n in names)


def _imports(tree):
    found = set()

    def walk(node, guarded):
        if isinstance(node, ast.Import) and not guarded:
            found.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and not guarded and node.level == 0 and node.module:
            found.add(node.module.split(".")[0])
        for child in ast.iter_child_nodes(node):
            g = guarded
            if isinstance(node, ast.Try) and child in node.body and any(
                _catches_import(h) for h in node.handlers
            ):
                g = True
            walk(child, g)

    walk(tree, False)
    return found


def auto_install(code, log):
    """Install every imported module that is not available yet (pure-Python only)."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return
    import importlib.util

    for name in sorted(_imports(tree)):
        if name in _STD or name in _FAILED or name == "__future__":
            continue
        try:
            if importlib.util.find_spec(name) is not None:
                continue
        except Exception:
            pass
        dist = ALIASES.get(name, name)
        log("[PyStudio] '%s' is not installed - installing %s" % (name, dist))
        try:
            _install_one(dist, log, set())
        except urllib.error.URLError as e:
            _FAILED.add(name)
            log("[PyStudio] no internet? (%s)" % getattr(e, "reason", e))
        except Exception as e:
            _FAILED.add(name)
            log("[PyStudio] could not install '%s': %s" % (dist, e))
