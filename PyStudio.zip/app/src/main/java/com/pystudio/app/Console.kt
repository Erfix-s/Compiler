package com.pystudio.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

sealed class Item {
    abstract val id: Long
}

data class Txt(override val id: Long, val text: String, val err: Boolean) : Item()
data class Img(override val id: Long, val path: String, val ver: Int) : Item()

enum class Status { IDLE, RUNNING, OK, ERROR, STOPPED }

fun statusColor(s: Status): Color = when (s) {
    Status.IDLE -> Dim
    Status.RUNNING -> Amber
    Status.OK -> Mint
    Status.ERROR -> Rose
    Status.STOPPED -> Amber
}

fun statusLabel(s: Status, ms: Long): String {
    val t = "%.1f s".format(ms / 1000.0)
    return when (s) {
        Status.IDLE -> "Ready"
        Status.RUNNING -> "Running  $t"
        Status.OK -> "Finished in $t"
        Status.ERROR -> "Failed after $t"
        Status.STOPPED -> "Stopped after $t"
    }
}

@Composable
fun ConsolePanel(
    feed: List<Item>,
    status: Status,
    elapsed: Long,
    awaiting: Boolean,
    height: Dp,
    onDrag: (Float) -> Unit,
    onClose: () -> Unit,
    onClear: () -> Unit,
    onSend: (String) -> Unit,
    onImage: (Img) -> Unit
) {
    val shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    val list = rememberLazyListState()
    val tail = (feed.lastOrNull() as? Txt)?.text?.length ?: 0
    LaunchedEffect(feed.size, tail, awaiting) {
        if (feed.isNotEmpty() && (status == Status.RUNNING || awaiting)) list.scrollToItem(feed.lastIndex)
    }
    Column(
        Modifier.fillMaxWidth().height(height).clip(shape)
            .background(Color(0xFF080D18)).border(1.dp, Line, shape)
    ) {
        Column(
            Modifier.fillMaxWidth().pointerInput(Unit) {
                detectVerticalDragGestures { change, dy ->
                    change.consume()
                    onDrag(dy)
                }
            }
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp)
                    .size(width = 40.dp, height = 4.dp).clip(CircleShape).background(Line)
            )
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(statusColor(status)))
                Spacer(Modifier.width(8.dp))
                Text(
                    statusLabel(status, elapsed), color = Ink, fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp, modifier = Modifier.weight(1f)
                )
                Text(
                    "Clear", color = Dim, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClear)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
                Text(
                    "\u2715", color = Dim, fontSize = 15.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClose)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (feed.isEmpty()) {
                Text("Output appears here", color = Dim, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            } else {
                SelectionContainer {
                    LazyColumn(
                        state = list,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(feed, key = { it.id }) { item ->
                            when (item) {
                                is Txt -> Text(
                                    item.text, color = if (item.err) Rose else Ink,
                                    fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp
                                )
                                is Img -> Column(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card2)
                                        .clickable { onImage(item) }
                                ) {
                                    AsyncImg(item.path, 1000, Modifier.fillMaxWidth(), ContentScale.FillWidth, item.ver)
                                    Text(
                                        File(item.path).nameWithoutExtension.substringAfter('_'),
                                        color = Dim, fontSize = 12.sp, modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        if (awaiting) InputRow(onSend)
    }
}

@Composable
private fun InputRow(onSend: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    Row(
        Modifier.fillMaxWidth().background(Card).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("\u276F", color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 16.sp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            BasicTextField(
                value = t,
                onValueChange = { t = it },
                singleLine = true,
                textStyle = TextStyle(color = Ink, fontFamily = FontFamily.Monospace, fontSize = 15.sp),
                cursorBrush = SolidColor(Cyan),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    onSend(t)
                    t = ""
                }),
                modifier = Modifier.fillMaxWidth().focusRequester(fr)
            )
        }
        Text(
            "Send", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(Grad)
                .clickable {
                    onSend(t)
                    t = ""
                }.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun ConsoleBar(status: Status, elapsed: Long, onOpen: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(shape).background(Card).border(1.dp, Line, shape)
            .clickable(onClick = onOpen).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(statusColor(status)))
        Spacer(Modifier.width(10.dp))
        Text("Console", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(statusLabel(status, elapsed), color = Dim, fontSize = 12.sp)
        Spacer(Modifier.width(10.dp))
        Text("\u2303", color = Dim, fontSize = 16.sp)
    }
}
