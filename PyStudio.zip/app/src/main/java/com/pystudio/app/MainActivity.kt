package com.pystudio.app

import android.graphics.Color as AColor
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, background = Bg, surface = Card, onSurface = Ink
                )
            ) { PyStudio() }
        }
    }
}

@Composable
fun PyStudio() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by remember { mutableIntStateOf(0) }
    var code by remember { mutableStateOf(TextFieldValue(SAMPLES[1].second)) }
    var images by remember { mutableStateOf(listFiles(inputsDir(ctx))) }
    var results by remember { mutableStateOf(listFiles(outputsDir(ctx))) }
    var output by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(Status.IDLE) }
    var took by remember { mutableLongStateOf(0L) }
    var runId by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf("Starting Python\u2026") }
    var ready by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val r = withContext(Dispatchers.IO) { runCatching { Py.start(ctx) } }
        r.onSuccess { info = it; ready = true }
            .onFailure { info = "Python failed to start: " + it.message }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            importImages(ctx, uris)
            images = listFiles(inputsDir(ctx))
        }
    }

    fun run() {
        if (!ready || status == Status.RUNNING) return
        status = Status.RUNNING; output = ""; error = ""; tab = 2
        scope.launch {
            val t0 = System.currentTimeMillis()
            val r = withContext(Dispatchers.Default) { runCatching { Py.run(code.text) } }
            took = System.currentTimeMillis() - t0
            val res = r.getOrElse { RunResult(false, "", it.message ?: "Python bridge error") }
            output = res.out
            error = res.err
            status = if (res.ok) Status.OK else Status.ERROR
            results = listFiles(outputsDir(ctx))
            runId++
            if (res.ok && results.isNotEmpty()) tab = 3
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding()) {
        Box(
            Modifier.size(340.dp).offset(x = (-110).dp, y = (-170).dp)
                .background(Brush.radialGradient(listOf(Violet.copy(alpha = 0.30f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomEnd).size(300.dp).offset(x = 120.dp, y = 140.dp)
                .background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.18f), Color.Transparent)), CircleShape)
        )

        Column(Modifier.fillMaxSize()) {
            Header(info, ready)
            Tabs(
                listOf(
                    "Code",
                    "Images" + if (images.isEmpty()) "" else " (" + images.size + ")",
                    "Output",
                    "Results" + if (results.isEmpty()) "" else " (" + results.size + ")"
                ),
                tab
            ) { tab = it }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> EditorTab(code, { code = it }) { code = TextFieldValue(it) }
                    1 -> ImagesTab(
                        images,
                        onAdd = { picker.launch(arrayOf("image/*")) },
                        onDelete = { it.delete(); images = listFiles(inputsDir(ctx)) }
                    )
                    2 -> OutputTab(status, output, error, took)
                    else -> ResultsTab(results, runId) { f ->
                        val ok = saveToGallery(ctx, f)
                        Toast.makeText(
                            ctx,
                            if (ok) "Saved to Pictures/PyStudio" else "Could not save the image",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                RunButton(status == Status.RUNNING, ready) { run() }
            }
        }
    }
}

@Composable
fun Header(info: String, ready: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Grad),
            contentAlignment = Alignment.Center
        ) { Text("Py", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("PyStudio", color = Ink, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(info, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ready) Mint else Amber))
    }
}

@Composable
fun Tabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            .clip(shape).background(Card).border(1.dp, Line, shape).padding(4.dp)
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .then(if (on) Modifier.background(Grad) else Modifier)
                    .clickable { onSelect(i) }.padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, color = if (on) Color.White else Dim,
                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1
                )
            }
        }
    }
}

@Composable
fun BoxScope.RunButton(running: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.align(Alignment.BottomEnd).padding(20.dp)
            .alpha(if (enabled) 1f else 0.5f)
            .shadow(24.dp, shape, ambientColor = Violet, spotColor = Cyan)
            .clip(shape).background(Grad)
            .clickable(enabled = enabled && !running, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (running) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.5.dp)
        else Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
        Spacer(Modifier.width(8.dp))
        Text(if (running) "Running" else "Run", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun EditorTab(code: TextFieldValue, onCode: (TextFieldValue) -> Unit, onSample: (String) -> Unit) {
    val highlight = remember { PyHighlight() }
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(SAMPLES) { (name, src) ->
                Text(
                    name, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Card2)
                        .border(1.dp, Line, RoundedCornerShape(50))
                        .clickable { onSample(src) }.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                .clip(shape).background(Card).border(1.dp, Line, shape)
        ) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                BasicTextField(
                    value = code,
                    onValueChange = onCode,
                    textStyle = TextStyle(
                        color = Ink, fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp, lineHeight = 22.sp
                    ),
                    cursorBrush = SolidColor(Cyan),
                    visualTransformation = highlight,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp)
                )
                Spacer(Modifier.height(96.dp))
            }
        }
    }
}

@Composable
fun OutputTab(status: Status, output: String, error: String, took: Long) {
    val (label, color) = when (status) {
        Status.IDLE -> "Ready" to Dim
        Status.RUNNING -> "Running\u2026" to Amber
        Status.OK -> "Finished in " + "%.2f".format(took / 1000.0) + " s" to Mint
        Status.ERROR -> "Stopped with an error" to Rose
    }
    val shape = RoundedCornerShape(20.dp)
    val text = buildAnnotatedString {
        if (output.isEmpty() && error.isEmpty()) {
            withStyle(SpanStyle(color = Dim)) {
                append(if (status == Status.RUNNING) "Running your code\u2026" else "Run your code to see what it prints.")
            }
        } else {
            withStyle(SpanStyle(color = Ink)) { append(output) }
            if (error.isNotEmpty()) withStyle(SpanStyle(color = Rose)) { append(error) }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
                .border(1.dp, Line, RoundedCornerShape(16.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Text(label, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(bottom = 12.dp)
                .clip(shape).background(Color(0xFF04070D)).border(1.dp, Line, shape)
        ) {
            SelectionContainer {
                Text(
                    text, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp,
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
                )
            }
        }
    }
}

@Composable
fun ImagesTab(images: List<File>, onAdd: () -> Unit, onDelete: (File) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Box(
                Modifier.aspectRatio(1f).clip(shape).background(Card)
                    .border(1.dp, Cyan.copy(alpha = 0.55f), shape).clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Add, null, tint = Cyan, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.height(6.dp))
                    Text("Add images", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("from your phone", color = Dim, fontSize = 12.sp)
                }
            }
        }
        items(images, key = { it.name }) { f ->
            Box(Modifier.aspectRatio(1f).clip(shape).background(Card)) {
                AsyncImg(f.absolutePath, 420, Modifier.fillMaxSize(), ContentScale.Crop, f.lastModified())
                Box(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                        .padding(start = 10.dp, end = 10.dp, top = 18.dp, bottom = 8.dp)
                ) {
                    Text(f.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(30.dp).clip(CircleShape)
                        .background(Color(0x99000000)).clickable { onDelete(f) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(
                Modifier.fillMaxWidth().clip(shape).background(Card2).border(1.dp, Line, shape).padding(16.dp)
            ) {
                Text("Use them in Python", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "from studio import images\nfor path in images(): ...",
                    color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ResultsTab(results: List<File>, runId: Int, onSave: (File) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    if (results.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Nothing here yet", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text("Call show(image) in your code and the picture appears here.", color = Dim, fontSize = 13.sp)
        }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(results, key = { it.name }) { f ->
            Column(Modifier.fillMaxWidth().clip(shape).background(Card).border(1.dp, Line, shape)) {
                AsyncImg(f.absolutePath, 1200, Modifier.fillMaxWidth(), ContentScale.FillWidth, runId)
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name, color = Dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(
                        "Save to Photos", color = Cyan, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onSave(f) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AsyncImg(path: String, target: Int, modifier: Modifier, scale: ContentScale, key: Any = path) {
    val bmp by produceState<ImageBitmap?>(null, path, key) {
        value = withContext(Dispatchers.IO) { decode(path, target)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = scale)
    else Box(modifier.defaultMinSize(minHeight = 160.dp).background(Card2))
}
