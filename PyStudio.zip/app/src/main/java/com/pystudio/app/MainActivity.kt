package com.pystudio.app

import android.content.Context
import android.graphics.Color as AColor
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, background = Bg, surface = Card, onSurface = Ink
                )
            ) { PyStudio(tick) }
        }
    }

    // coming back from the "All files access" settings screen re-checks the permission
    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
fun PyStudio(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("pystudio", Context.MODE_PRIVATE) }
    val root = remember { Environment.getExternalStorageDirectory() }
    val granted = remember(tick) { hasAllFiles() }

    var tab by remember { mutableIntStateOf(0) }
    var code by remember { mutableStateOf(TextFieldValue(prefs.getString("code", null) ?: SAMPLES[1].second)) }
    var cwd by remember { mutableStateOf(prefs.getString("cwd", null) ?: root.absolutePath) }
    var dir by remember { mutableStateOf(File(cwd).takeIf { it.isDirectory } ?: root) }
    var results by remember { mutableStateOf(listFiles(outputsDir(ctx))) }
    var output by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(Status.IDLE) }
    var took by remember { mutableLongStateOf(0L) }
    var runId by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf("Starting Python\u2026") }
    var ready by remember { mutableStateOf(false) }

    val entries = remember(dir, granted, runId) { listDir(dir) }

    LaunchedEffect(Unit) {
        val r = withContext(Dispatchers.IO) { runCatching { Py.start(ctx) } }
        r.onSuccess { info = it; ready = true }
            .onFailure { info = "Python failed to start: " + it.message }
    }

    BackHandler(enabled = tab == 1 && dir.absolutePath != root.absolutePath) {
        dir = dir.parentFile ?: root
    }

    fun setCode(v: TextFieldValue) {
        code = v
        prefs.edit().putString("code", v.text).apply()
    }

    fun run() {
        if (!ready || status == Status.RUNNING) return
        status = Status.RUNNING; output = ""; error = ""; tab = 2
        val src = code.text
        val folder = cwd
        scope.launch {
            val t0 = System.currentTimeMillis()
            val r = withContext(Dispatchers.Default) { runCatching { Py.run(src, folder) } }
            took = System.currentTimeMillis() - t0
            val res = r.getOrElse { RunResult(false, "", it.message ?: "Python bridge error") }
            output = res.out
            error = res.err
            status = if (res.ok) Status.OK else Status.ERROR
            results = listFiles(outputsDir(ctx))
            runId++
            if (res.ok && results.isNotEmpty()) tab = 3
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding()) {
        Box(
            Modifier.size(340.dp).offset(x = (-110).dp, y = (-170).dp)
                .background(Brush.radialGradient(listOf(Violet.copy(alpha = 0.30f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomEnd).size(300.dp).offset(x = 120.dp, y = 140.dp)
                .background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.18f), Color.Transparent)), CircleShape)
        )

        Column(Modifier.fillMaxSize()) {
            Header(info, ready)
            Tabs(
                listOf(
                    "Code",
                    "Files",
                    "Output",
                    "Results" + if (results.isEmpty()) "" else " (" + results.size + ")"
                ),
                tab
            ) { tab = it }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> EditorTab(
                        code = code,
                        folder = prettyPath(File(cwd), root),
                        onCode = { setCode(it) },
                        onFolder = { tab = 1 },
                        onSample = { setCode(TextFieldValue(it)) }
                    )
                    1 -> FilesTab(
                        granted = granted,
                        root = root,
                        dir = dir,
                        entries = entries,
                        cwd = cwd,
                        onGrant = { openAllFilesSettings(ctx) },
                        onUp = { dir = dir.parentFile ?: root },
                        onUse = {
                            cwd = dir.absolutePath
                            prefs.edit().putString("cwd", cwd).apply()
                        },
                        onTap = { f ->
                            if (f.isDirectory) {
                                dir = f
                            } else {
                                val p = if (f.parentFile?.absolutePath == cwd) f.name else f.absolutePath
                                setCode(insertText(code, "\"" + p + "\""))
                                tab = 0
                            }
                        }
                    )
                    2 -> OutputTab(status, output, error, took)
                    else -> ResultsTab(results, runId) { f ->
                        val ok = saveToGallery(ctx, f)
                        Toast.makeText(
                            ctx,
                            if (ok) "Saved to Pictures/PyStudio" else "Could not save the image",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                RunButton(status == Status.RUNNING, ready) { run() }
            }
        }
    }
}

@Composable
fun Header(info: String, ready: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Grad),
            contentAlignment = Alignment.Center
        ) { Text("Py", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("PyStudio", color = Ink, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(info, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ready) Mint else Amber))
    }
}

@Composable
fun Tabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            .clip(shape).background(Card).border(1.dp, Line, shape).padding(4.dp)
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .then(if (on) Modifier.background(Grad) else Modifier)
                    .clickable { onSelect(i) }.padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, color = if (on) Color.White else Dim,
                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1
                )
            }
        }
    }
}

@Composable
fun BoxScope.RunButton(running: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.align(Alignment.BottomEnd).padding(20.dp)
            .alpha(if (enabled) 1f else 0.5f)
            .shadow(24.dp, shape, ambientColor = Violet, spotColor = Cyan)
            .clip(shape).background(Grad)
            .clickable(enabled = enabled && !running, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (running) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.5.dp)
        else Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
        Spacer(Modifier.width(8.dp))
        Text(if (running) "Running" else "Run", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun EditorTab(
    code: TextFieldValue,
    folder: String,
    onCode: (TextFieldValue) -> Unit,
    onFolder: () -> Unit,
    onSample: (String) -> Unit
) {
    val highlight = remember { PyHighlight() }
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(SAMPLES) { (name, src) ->
                Text(
                    name, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Card2)
                        .border(1.dp, Line, RoundedCornerShape(50))
                        .clickable { onSample(src) }.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        Text(
            "\uD83D\uDCC2  " + folder, color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(50)).clickable(onClick = onFolder).padding(horizontal = 6.dp, vertical = 4.dp)
        )
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                .clip(shape).background(Card).border(1.dp, Line, shape)
        ) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                BasicTextField(
                    value = code,
                    onValueChange = onCode,
                    textStyle = TextStyle(
                        color = Ink, fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp, lineHeight = 22.sp
                    ),
                    cursorBrush = SolidColor(Cyan),
                    visualTransformation = highlight,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp)
                )
                Spacer(Modifier.height(96.dp))
            }
        }
    }
}

@Composable
fun FilesTab(
    granted: Boolean,
    root: File,
    dir: File,
    entries: List<File>,
    cwd: String,
    onGrant: () -> Unit,
    onUp: () -> Unit,
    onUse: () -> Unit,
    onTap: (File) -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    if (!granted) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Column(Modifier.fillMaxWidth().clip(shape).background(Card).border(1.dp, Line, shape).padding(20.dp)) {
                Text("Allow access to your files", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "PyStudio needs \"All files access\" so your code can open and save photos directly, like on a PC.",
                    color = Dim, fontSize = 13.sp, lineHeight = 19.sp
                )
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(Grad)
                        .clickable(onClick = onGrant).padding(horizontal = 20.dp, vertical = 12.dp)
                ) { Text("Open settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            }
        }
        return
    }
    val isCwd = dir.absolutePath == cwd
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    prettyPath(dir, root), color = Ink, fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text("Tap a photo to put its name in your code", color = Dim, fontSize = 12.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text(
                if (isCwd) "\u2713 Working folder" else "Use this folder",
                color = if (isCwd) Mint else Color.White,
                fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(50))
                    .then(
                        if (isCwd) Modifier.border(1.dp, Mint, RoundedCornerShape(50))
                        else Modifier.background(Grad)
                    )
                    .clickable(enabled = !isCwd, onClick = onUse)
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 10.dp, end = 10.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            if (dir.absolutePath != root.absolutePath) {
                item { FileRow("\u2191", null, "Up", "Parent folder", onUp) }
            }
            items(entries, key = { it.absolutePath }) { f ->
                when {
                    f.isDirectory -> FileRow("\uD83D\uDCC1", null, f.name, "Folder") { onTap(f) }
                    isImage(f) -> FileRow("\uD83D\uDDBC", f, f.name, fmtSize(f.length())) { onTap(f) }
                    else -> FileRow("\uD83D\uDCC4", null, f.name, fmtSize(f.length())) { onTap(f) }
                }
            }
        }
    }
}

@Composable
fun FileRow(icon: String, thumb: File?, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Card2),
            contentAlignment = Alignment.Center
        ) {
            if (thumb != null) AsyncImg(thumb.absolutePath, 128, Modifier.fillMaxSize(), ContentScale.Crop, thumb.lastModified())
            else Text(icon, fontSize = 22.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Dim, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
fun OutputTab(status: Status, output: String, error: String, took: Long) {
    val (label, color) = when (status) {
        Status.IDLE -> "Ready" to Dim
        Status.RUNNING -> "Running\u2026" to Amber
        Status.OK -> "Finished in " + "%.2f".format(took / 1000.0) + " s" to Mint
        Status.ERROR -> "Stopped with an error" to Rose
    }
    val shape = RoundedCornerShape(20.dp)
    val text = buildAnnotatedString {
        if (output.isEmpty() && error.isEmpty()) {
            withStyle(SpanStyle(color = Dim)) {
                append(if (status == Status.RUNNING) "Running your code\u2026" else "Run your code to see what it prints.")
            }
        } else {
            withStyle(SpanStyle(color = Ink)) { append(output) }
            if (error.isNotEmpty()) withStyle(SpanStyle(color = Rose)) { append(error) }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
                .border(1.dp, Line, RoundedCornerShape(16.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Text(label, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(bottom = 12.dp)
                .clip(shape).background(Color(0xFF04070D)).border(1.dp, Line, shape)
        ) {
            SelectionContainer {
                Text(
                    text, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp,
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
                )
            }
        }
    }
}

@Composable
fun ResultsTab(results: List<File>, runId: Int, onSave: (File) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    if (results.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Nothing here yet", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text("Call cv2.imshow(\"title\", img) and the picture appears here.", color = Dim, fontSize = 13.sp)
        }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(results, key = { it.name }) { f ->
            Column(Modifier.fillMaxWidth().clip(shape).background(Card).border(1.dp, Line, shape)) {
                AsyncImg(f.absolutePath, 1200, Modifier.fillMaxWidth(), ContentScale.FillWidth, runId)
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        f.nameWithoutExtension.substringAfter('_'), color = Ink, fontSize = 13.sp,
                        fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)
                    )
                    Text(
                        "Save to Photos", color = Cyan, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onSave(f) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AsyncImg(path: String, target: Int, modifier: Modifier, scale: ContentScale, key: Any = path) {
    val bmp by produceState<ImageBitmap?>(null, path, key) {
        value = withContext(Dispatchers.IO) { decode(path, target)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = scale)
    else Box(modifier.defaultMinSize(minHeight = 160.dp).background(Card2))
}
