package com.pystudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.exifinterface.media.ExifInterface
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

// ---------- palette ----------
val Bg = Color(0xFF060A13)
val Card = Color(0xFF0E1525)
val Card2 = Color(0xFF151F36)
val Line = Color(0xFF212D4A)
val Ink = Color(0xFFE8EDFF)
val Dim = Color(0xFF8692B3)
val Cyan = Color(0xFF22D3EE)
val Violet = Color(0xFF8B5CF6)
val Pink = Color(0xFFF472B6)
val Mint = Color(0xFF34D399)
val Amber = Color(0xFFFBBF24)
val Rose = Color(0xFFFB7185)
val Grad = Brush.linearGradient(listOf(Cyan, Violet))

// ---------- python bridge ----------
enum class Status { IDLE, RUNNING, OK, ERROR }

class RunResult(val ok: Boolean, val out: String, val err: String)

object Py {
    private fun mod() = Python.getInstance().getModule("studio")

    fun start(ctx: Context): String {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx.applicationContext))
        mod().callAttr("setup", outputsDir(ctx).absolutePath)
        return mod().callAttr("info").toString()
    }

    fun run(code: String, cwd: String): RunResult {
        val j = org.json.JSONObject(mod().callAttr("run", code, cwd).toString())
        return RunResult(j.getBoolean("ok"), j.getString("out"), j.getString("err"))
    }
}

// ---------- files & permission ----------
fun outputsDir(c: Context): File = File(c.filesDir, "outputs").apply { mkdirs() }

fun listFiles(dir: File): List<File> =
    dir.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()

/** Folders first, then files, hidden entries skipped. */
fun listDir(d: File): List<File> =
    (d.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList())
        .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))

private val IMG_EXT = setOf("jpg", "jpeg", "jfif", "png", "webp", "bmp", "gif", "tif", "tiff")
fun isImage(f: File) = f.isFile && f.extension.lowercase() in IMG_EXT

fun fmtSize(b: Long): String = when {
    b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
    b >= 1024 -> (b / 1024).toString() + " KB"
    else -> "$b B"
}

fun prettyPath(d: File, root: File): String = "Phone" + d.absolutePath.removePrefix(root.absolutePath)

fun hasAllFiles(): Boolean = Environment.isExternalStorageManager()

fun openAllFilesSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
        )
    } catch (e: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

fun insertText(v: TextFieldValue, s: String): TextFieldValue {
    val a = v.selection.min
    val b = v.selection.max
    return TextFieldValue(v.text.replaceRange(a, b, s), TextRange(a + s.length))
}

fun saveToGallery(ctx: Context, f: File): Boolean = runCatching {
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PyStudio_" + System.currentTimeMillis() + ".png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PyStudio")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
}.isSuccess

/** Down-sampled decode that also respects the photo's EXIF rotation. */
fun decode(path: String, target: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        ?: return null
    val orientation = runCatching {
        ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
    }.getOrDefault(1)
    val deg = when (orientation) {
        6 -> 90f
        3 -> 180f
        8 -> 270f
        else -> 0f
    }
    if (deg == 0f) return bmp
    val m = Matrix().apply { postRotate(deg) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

// ---------- syntax highlighting ----------
class PyHighlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        fun paint(r: Regex, c: Color) {
            r.findAll(s).forEach { b.addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1) }
        }
        paint(NUM, Amber)
        paint(KW, Pink)
        paint(FN, Cyan)
        paint(STR, Mint)
        paint(COM, Dim)
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }

    private companion object {
        val NUM = Regex("""\b\d+(\.\d+)?\b""")
        val KW = Regex("""\b(def|class|import|from|as|return|if|elif|else|for|while|in|not|and|or|is|try|except|finally|with|lambda|pass|break|continue|None|True|False|raise|yield|global)\b""")
        val FN = Regex("""\b(print|len|range|open|int|str|float|list|dict|set|tuple|enumerate|zip|map|sum|min|max|abs|sorted|isinstance)\b|(?<=def\s)\w+|(?<=class\s)\w+""")
        val STR = Regex("""("{3}[\s\S]*?"{3}|'{3}[\s\S]*?'{3}|"[^"\n]*"|'[^'\n]*')""")
        val COM = Regex("""#[^\n]*""")
    }
}

// ---------- starter scripts ----------
val SAMPLES: List<Pair<String, String>> = listOf(
    "Hello" to """
import platform
print("Hello from Python", platform.python_version())

squares = [n * n for n in range(1, 11)]
print(squares)
""".trimIndent(),

    "imshow" to """
import cv2
import numpy as np

img = np.zeros((300, 500, 3), np.uint8)
img[:] = (255, 120, 40)
cv2.putText(img, "imshow works!", (60, 160), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 3)

cv2.imshow("pic1", img)
cv2.waitKey(0)
""".trimIndent(),

    "NumPy art" to """
import numpy as np
from studio import show

h, w = 360, 640
y, x = np.mgrid[0:h, 0:w]
r = (np.sin(x / 38.0) + 1) * 127
g = (np.cos(y / 29.0) + 1) * 127
b = (x + y) % 256
show(np.dstack([r, g, b]), "art")
""".trimIndent(),

    "Photos" to """
from studio import images, show
from PIL import Image, ImageOps, ImageFilter

files = images()
print(len(files), "image(s) in the working folder")
if not files:
    print("Open the Files tab, pick a folder, tap 'Use this folder'.")

for path in files[:3]:
    im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    print(path.split("/")[-1], im.size)
    im.thumbnail((900, 900))
    show(ImageOps.grayscale(im), "gray")
    show(im.filter(ImageFilter.CONTOUR), "contour")
""".trimIndent(),

    "OpenCV" to """
import cv2
from studio import images

for path in images()[:2]:
    img = cv2.imread(path)
    if img is None:
        print("Could not read", path)
        continue
    img = cv2.resize(img, None, fx=0.4, fy=0.4)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imshow("edges", cv2.Canny(gray, 80, 160))
    cv2.imshow("photo", img)
""".trimIndent()
)
