package dev.pyvision.ide

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.graphics.asImageBitmap\nimport androidx.compose.ui.graphics.graphicsLayer\nimport androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF121A2B)
private val Panel2 = Color(0xFF1A263A)
private val Accent = Color(0xFF63D6B2)
private val Muted = Color(0xFF8FA1B8)

class MainActivity : ComponentActivity() {
    private var selectedUris by mutableStateOf<List<Uri>>(emptyList())
    private val imagePicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        selectedUris = uris
        uris.forEach { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }
    private val savePicker = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) exportImage(uri)
    }
    private var lastOutput: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent, onBackground = Color.White,
                onSurface = Color.White, secondary = Color(0xFF8A9CFF)
            )) {
                IDEScreen(
                    onPickImages = { imagePicker.launch(arrayOf("image/jpeg", "image/png", "image/webp")) },
                    onRun = { code, callback -> runPython(code, callback) },
                    onSave = { if (lastOutput?.exists() == true) savePicker.launch("pyvision-output.png") },
                    imageCount = selectedUris.size
                )
            }
        }
    }

    private fun runPython(code: String, callback: (String, String?) -> Unit) {
        Thread {
            try {
                val workspace = File(filesDir, "workspace").apply { mkdirs() }
                val inputDir = File(workspace, "input").apply { mkdirs() }
                selectedUris.forEachIndexed { i, uri ->
                    contentResolver.openInputStream(uri)?.use { input ->
                        File(inputDir, "image_${i + 1}.${extension(uri)}").outputStream().use(input::copyTo)
                    }
                }
                val script = File(workspace, "main.py").apply { writeText(code) }
                val py = Python.getInstance()
                val result = py.getModule("runner").callAttr("execute", script.absolutePath, workspace.absolutePath)
                val output = result.toString()
                val image = File(workspace, "output.png")
                lastOutput = image.takeIf { it.exists() }
                runOnUiThread { callback(output, lastOutput?.absolutePath, null) }
            } catch (e: Exception) {
                runOnUiThread { callback("", null, e.stackTraceToString()) }
            }
        }.start()
    }

    private fun extension(uri: Uri): String {
        val type = contentResolver.getType(uri)
        return when (type) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
    }

    private fun exportImage(uri: Uri) {
        val source = lastOutput ?: return
        contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
    }
}

@Composable
private fun IDEScreen(
    onPickImages: () -> Unit,
    onRun: (String, (String, String?, String?) -> Unit) -> Unit,
    onSave: () -> Unit,
    imageCount: Int
) {
    var code by remember { mutableStateOf(
        "# PyVision IDE — Python image workspace\n" +
        "from PIL import Image, ImageOps\n" +
        "from pathlib import Path\n\n" +
        "inputs = sorted(Path('input').glob('*'))\n" +
        "if inputs:\n" +
        "    image = Image.open(inputs[0]).convert('RGB')\n" +
        "    result = ImageOps.grayscale(image)\n" +
        "    result.save('output.png')\n" +
        "    print(f'Processed: {inputs[0].name} → output.png')\n" +
        "else:\n" +
        "    print('Choose an image, then press Run.')\n"
    ) }
    var output by remember { mutableStateOf("Ready • Python 3.10 on-device") }
    var error by remember { mutableStateOf<String?>(null) }
    var outputPath by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("Editor") }
    var fileName by remember { mutableStateOf("main.py") }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.size(38.dp).background(Accent, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Terminal, null, tint = Bg)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("PyVision", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("PYTHON IMAGE LAB", fontSize = 9.sp, color = Muted, letterSpacing = 1.8.sp)
            }
            IconButton(onClick = onPickImages) { Icon(Icons.Default.AddPhotoAlternate, "Choose images", tint = Accent) }
            IconButton(onClick = { fileName = "main.py"; code = "# New Python file\n" }) { Icon(Icons.Default.NoteAdd, "New file") }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(4.dp)) {
            listOf("Editor", "Packages", "Images").forEach { item ->
                Box(Modifier.weight(1f).background(if (tab == item) Panel2 else Color.Transparent, RoundedCornerShape(9.dp)
                ).clickable { tab = item }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(item, color = if (tab == item) Accent else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            "Editor" -> {
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, null, tint = Accent, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(fileName, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Text("PY", color = Muted, fontSize = 10.sp)
                }
                BasicTextField(
                    value = code, onValueChange = { code = it },
                    modifier = Modifier.weight(1f).fillMaxWidth().background(Color(0xFF0E1626), RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)).padding(12.dp),
                    textStyle = TextStyle(color = Color(0xFFD7E1F0), fontSize = 13.sp, lineHeight = 20.sp, fontFamily = FontFamily.Monospace),
                    keyboardOptions = KeyboardOptions(autoCorrect = false),
                    decorationBox = { inner -> Box {
                        if (code.isEmpty()) Text("Write Python…", color = Muted)
                        inner()
                    } }
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$imageCount image(s) selected", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = onPickImages, contentPadding = PaddingValues(horizontal = 12.dp)) {
                        Icon(Icons.Default.Image, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Images")
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        running = true; error = null
                        onRun(code) { text, path, err -> output = text; outputPath = path; error = err; running = false }
                    }, enabled = !running, contentPadding = PaddingValues(horizontal = 16.dp)) {
                        Icon(if (running) Icons.Default.HourglassTop else Icons.Default.PlayArrow, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp)); Text(if (running) "Running" else "Run")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("CONSOLE", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Column(Modifier.fillMaxWidth().heightIn(min = 90.dp, max = 150.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text(error ?: output, color = if (error != null) Color(0xFFFF8D8D) else Color(0xFFB7C8DC),
                        fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    if (error != null) Text("Execution failed", color = Color(0xFFFF8D8D), fontSize = 10.sp)
                }
                if (outputPath != null) Text("Output: $outputPath", color = Accent, fontSize = 10.sp)
            }
            "Packages" -> PackagePanel()
            else -> ImagePanel(outputPath, onSave)
        }
        Spacer(Modifier.height(8.dp))
        Text("Chaquopy runtime  •  Android local execution", color = Color(0xFF60738D), fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun PackagePanel() {
    val packages = listOf(
        "NumPy" to "numpy", "OpenCV" to "cv2", "Pillow" to "PIL", "SciPy" to "scipy",
        "Matplotlib" to "matplotlib", "ImageIO" to "imageio", "ImageHash" to "imagehash"
    )
    var states by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                val py = Python.getInstance().getModule("runner")
                val result = py.callAttr("package_status").toString()
                states = result.split(";").mapNotNull {
                    val p = it.split("="); if (p.size == 2) p[0] to p[1] else null
                }.toMap()
            } catch (_: Exception) { }
        }
    }
    Column(Modifier.fillMaxSize().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text("Python packages", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text("Android-compatible packages bundled into this build", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        packages.forEach { (label, module) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(module, color = Muted, fontSize = 10.sp)
                }
                Text(states[module] ?: "Checking…", color = if (states[module] == "installed") Accent else Muted, fontSize = 11.sp)
            }
            HorizontalDivider(color = Panel2)
        }
        Spacer(Modifier.height(10.dp))
        Text("Native wheels are resolved at build time for Android ABI. Adding/removing native packages requires a new APK; runtime pip mutation is intentionally not simulated.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun ImagePanel(outputPath: String?, onSave: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp)) {
        Text("Image outputs", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("The script writes output.png in the workspace. Pinch to zoom the latest rendered result.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (outputPath != null) {
            val bitmap = remember(outputPath) { android.graphics.BitmapFactory.decodeFile(outputPath) }
            if (bitmap != null) {
                var scale by remember(outputPath) { mutableFloatStateOf(1f) }
                androidx.compose.foundation.Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Python output image",
                    modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF0E1626), RoundedCornerShape(10.dp))
                        .pointerInput(outputPath) {
                            androidx.compose.foundation.gestures.detectTransformGestures { _, _, zoom, _ ->
                                scale = (scale * zoom).coerceIn(0.5f, 5f)
                            }
                        }.graphicsLayer { scaleX = scale; scaleY = scale }
                )
            } else {
                Text("Output file exists but could not be decoded.", color = Muted, fontSize = 12.sp)
            }
        } else {
            Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF0E1626), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center) {
                Text("Run a script that saves output.png to preview it here.", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Image, null, tint = Accent)
            Spacer(Modifier.width(8.dp))
            Text("Latest output: output.png", modifier = Modifier.weight(1f), fontSize = 13.sp)
            Button(onClick = onSave) { Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(5.dp)); Text("Save") }
        }
        Spacer(Modifier.height(12.dp))
        Text("Tip: use PIL.Image.open('input/image_1.jpg') or cv2.imread('input/image_1.jpg') from your script.", color = Muted, fontSize = 11.sp)
    }
}
