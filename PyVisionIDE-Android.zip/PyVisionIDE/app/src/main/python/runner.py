import contextlib
import io
import os
import sys
import traceback
import importlib.util

def execute(script_path, workspace):
    os.chdir(workspace)
    os.environ["HOME"] = workspace
    output = io.StringIO()
    try:
        with open(script_path, "r", encoding="utf-8") as source:
            code = compile(source.read(), script_path, "exec")
        namespace = {"__name__": "__main__", "__file__": script_path}
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(code, namespace, namespace)
        return output.getvalue() or "✓ Script finished successfully."
    except Exception:
        return output.getvalue() + traceback.format_exc()

def package_status():
    modules = ["numpy", "cv2", "PIL", "scipy", "matplotlib", "imageio", "imagehash"]
    return ";".join("%s=%s" % (name, "installed" if importlib.util.find_spec(name) else "not installed") for name in modules)
