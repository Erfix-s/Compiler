# PyVision IDE (Android)

یک محیط اجرای واقعی Python روی Android با Kotlin/Jetpack Compose و Chaquopy است. اجرای اسکریپت در خود دستگاه انجام می‌شود؛ اسکریپت‌ها در فضای خصوصی برنامه ذخیره می‌شوند و تصاویر با Android Storage Access Framework انتخاب می‌شوند.

## وضعیت فنی و سازگاری

- Runtime: CPython 3.10 از طریق Chaquopy 17.2؛ حداقل Android API 24؛ ABIهای arm64-v8a و x86_64.
- بسته‌های پیکربندی‌شده برای حل wheel اندرویدی: NumPy، Pillow، SciPy، Matplotlib، ImageIO، ImageHash و OpenCV headless (نسخه 4.5.1.48).
- Chaquopy بسته‌های pip را هنگام ساخت APK وارد می‌کند. این پروژه نصب/حذف آزاد بسته‌های native در زمان اجرا را ادعا نمی‌کند؛ Android wheel باید برای ABI و نسخه Python دقیقاً موجود باشد و کتابخانه‌های native نیازمند rebuild هستند.
- scikit-image، rembg و Albumentations عمداً در فهرست پیش‌فرض نصب قرار نگرفته‌اند: زنجیره وابستگی/native آن‌ها (به‌ویژه ONNX Runtime برای rembg و OpenCV برای Albumentations) باید جداگانه برای Android CPython 3.10 و ABI هدف اعتبارسنجی و بسته‌بندی شود. نمایش «نصب‌شده» بدون wheel واقعی انجام نمی‌شود.
- فایل‌های انتخابی از طریق SAF خوانده و در workspace خصوصی کپی می‌شوند؛ نام‌های ورودی `input/image_N.ext` هستند. خروجی `output.png` در workspace ساخته می‌شود.

## Build محلی

1. Android Studio / JDK 17 و Android SDK Platform 35 را نصب کنید.
2. پروژه را باز کنید و Gradle Sync را اجرا کنید.
3. برای APK: `gradle :app:assembleDebug`
4. خروجی: `app/build/outputs/apk/debug/app-debug.apk`

ساخت اولیه برای دانلود wheelهای Chaquopy به اینترنت نیاز دارد و ممکن است به‌دلیل نبود wheel سازگار یک بسته در مخزن Android شکست بخورد. خطای pip در Gradle Sync/Build را بررسی کنید؛ بسته ناسازگار را از `pip` block حذف یا برای ABI هدف wheel معتبر تهیه کنید.

## نمونه کد

```python
from PIL import Image, ImageOps
from pathlib import Path

files = list(Path("input").glob("*"))
if files:
    ImageOps.grayscale(Image.open(files[0])).save("output.png")
    print("saved output.png")
```

برای OpenCV:
```python
import cv2
img = cv2.imread("input/image_1.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imwrite("output.png", gray)
```

## محدودیت‌های نسخه فعلی

این تحویل یک پایه اجرایی قابل توسعه است، نه ادعای تکمیل همه ویژگی‌های IDE دسکتاپ: ویرایشگر فعلی TextField چندخطی با فونت monospace است و هنوز syntax highlighting واقعی، شماره خطوط، جست‌وجو/جایگزینی، breakpoint/debugger و توقف امن thread اجرا را ندارد. پنل خروجی در این نسخه مسیر فایل را نشان می‌دهد و خروجی PNG را صادر می‌کند؛ پیش‌نمایش تعاملی/مقایسه کنارهم در نسخه بعدی لازم است. انتخاب چند تصویر و اجرای محلی فراهم شده است. این موارد صادقانه ذکر شده‌اند تا قابلیت نمایشی به‌جای عملکرد واقعی جا زده نشود.

## معماری

- `MainActivity.kt`: UI، SAF، اجرای Python و export.
- `src/main/python/runner.py`: اجرای کد، capture خروجی و گزارش traceback.
- `app/build.gradle.kts`: runtime و Android wheels.
