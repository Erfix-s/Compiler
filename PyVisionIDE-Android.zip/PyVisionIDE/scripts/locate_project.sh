#!/usr/bin/env bash
set -euo pipefail
python3 scripts/extract_project.py project.zip extracted
