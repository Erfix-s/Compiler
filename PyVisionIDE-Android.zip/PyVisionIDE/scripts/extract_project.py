#!/usr/bin/env python3
"""Safely extract project.zip and locate the Gradle Android project."""
from pathlib import Path
import zipfile, sys

archive = Path(sys.argv[1] if len(sys.argv) > 1 else "project.zip").resolve()
destination = Path(sys.argv[2] if len(sys.argv) > 2 else ".").resolve()
if not archive.is_file():
    raise SystemExit(f"ERROR: archive not found: {archive}")
with zipfile.ZipFile(archive) as zf:
    root = destination
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        p = Path(name)
        if p.is_absolute() or ".." in p.parts:
            raise SystemExit(f"ERROR: unsafe ZIP member: {name}")
        target = (destination / p).resolve()
        if destination != target and destination not in target.parents:
            raise SystemExit(f"ERROR: path escapes destination: {name}")
        # Reject symlinks: ZIP metadata can otherwise create unsafe filesystem entries.
        mode = (info.external_attr >> 16) & 0o170000
        if mode == 0o120000:
            raise SystemExit(f"ERROR: symlink entry rejected: {name}")
    zf.extractall(destination)
# Accept either a project at archive root or one enclosing directory.
candidates = [destination] + [p for p in destination.iterdir() if p.is_dir()]
project = next((p for p in candidates if (p / "settings.gradle.kts").is_file() and (p / "app").is_dir()), None)
if project is None:
    raise SystemExit("ERROR: could not locate Android project (settings.gradle.kts + app/).")
print(f"PROJECT_DIR={project}")
